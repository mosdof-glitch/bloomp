import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/providers/cart_provider.dart';
import 'features/home/screens/home_screen.dart';
import 'features/catalog/screens/catalog_screen.dart';
import 'features/cart/screens/cart_screen.dart';
import 'features/profile/screens/profile_screen.dart';
import 'features/seller/screens/seller_dashboard.dart';
import 'shared/widgets/bottom_nav_bar.dart';

class MainNavigator extends StatefulWidget {
  const MainNavigator({super.key});

  @override
  State<MainNavigator> createState() => _MainNavigatorState();
}

class _MainNavigatorState extends State<MainNavigator> {
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    // Загружаем корзину из Firebase при старте
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<CartProvider>().loadCart();
      context.read<CartProvider>().listenToCart();
    });
  }

  final List<Widget> _screens = [
    const HomeScreen(),
    const CatalogScreen(),
    const SellerDashboard(),
    const CartScreen(),
    const ProfileScreen(),
  ];

  void _onNavTap(int index) {
    setState(() => _selectedIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: _screens,
      ),
      bottomNavigationBar: BottomNavBar(
        currentIndex: _selectedIndex,
        onTap: _onNavTap,
      ),
    );
  }
}
