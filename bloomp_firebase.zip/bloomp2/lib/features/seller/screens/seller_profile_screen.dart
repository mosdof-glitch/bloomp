import 'package:flutter/material.dart';
import '../models/seller_profile.dart';

class SellerProfileScreen extends StatefulWidget {
  const SellerProfileScreen({super.key});
  @override
  State<SellerProfileScreen> createState() => _SellerProfileScreenState();
}

class _SellerProfileScreenState extends State<SellerProfileScreen> {
  final SellerProfile _profile = SellerProfile(
    id: 'seller_123', name: 'Автозапчасти PRO',
    phone: '+7 701 234 56 78', email: 'auto@example.kz',
    sellerType: SellerType.shop, verificationStatus: VerificationStatus.none,
    businessName: 'ИП Ахметов А.А.', city: 'Алматы',
    rating: 4.8, reviewCount: 127, createdAt: DateTime(2024, 1, 15),
  );

  SellerType _selectedType = SellerType.shop;
  bool _hasChanges = false;
  final _nameCtrl = TextEditingController();
  final _bizCtrl = TextEditingController();
  final _binCtrl = TextEditingController();
  final _cityCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _selectedType = _profile.sellerType;
    _nameCtrl.text = _profile.name;
    _bizCtrl.text = _profile.businessName ?? '';
    _binCtrl.text = _profile.binIin ?? '';
    _cityCtrl.text = _profile.city ?? '';
  }

  @override
  void dispose() {
    _nameCtrl.dispose(); _bizCtrl.dispose();
    _binCtrl.dispose(); _cityCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F7),
      appBar: AppBar(
        title: const Text('Настройки профиля',
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white, elevation: 0,
        leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () => Navigator.pop(context)),
        actions: [
          if (_hasChanges)
            TextButton(
              onPressed: _save,
              child: const Text('Сохранить',
                  style: TextStyle(color: Color(0xFFF91155),
                      fontWeight: FontWeight.bold, fontSize: 16)),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _verBanner(),
          const SizedBox(height: 20),
          _sectionTitle('Тип продавца'),
          const SizedBox(height: 12),
          _typeSelector(),
          const SizedBox(height: 20),
          _sectionTitle('Основная информация'),
          const SizedBox(height: 12),
          _infoCard(),
          const SizedBox(height: 20),
          if (_selectedType != SellerType.individual) ...[
            _sectionTitle('Данные организации'),
            const SizedBox(height: 12),
            _bizCard(),
            const SizedBox(height: 20),
          ],
          SizedBox(
            height: 56,
            child: ElevatedButton(
              onPressed: _hasChanges ? _save : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF91155),
                disabledBackgroundColor: Colors.grey[300],
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                elevation: 0,
              ),
              child: const Text('Сохранить изменения',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold,
                      color: Colors.white)),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _sectionTitle(String t) => Text(t,
      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold));

  void _save() {
    setState(() => _hasChanges = false);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Профиль сохранён'), backgroundColor: Colors.green));
  }

  Widget _verBanner() {
    final s = _profile.verificationStatus;
    Color bc; Color bg; IconData ic; String title; String sub; bool showBtn;
    switch (s) {
      case VerificationStatus.verified:
        bc = Colors.green; bg = Colors.green.shade50; ic = Icons.verified;
        title = 'Verified ✅'; sub = 'Профиль верифицирован.'; showBtn = false;
        break;
      case VerificationStatus.pending:
        bc = Colors.orange; bg = Colors.orange.shade50; ic = Icons.hourglass_top;
        title = 'На рассмотрении'; sub = '1–3 рабочих дня.'; showBtn = false;
        break;
      case VerificationStatus.rejected:
        bc = Colors.red; bg = Colors.red.shade50; ic = Icons.cancel;
        title = 'Отклонена'; sub = 'Проверьте данные и подайте повторно.'; showBtn = true;
        break;
      default:
        bc = const Color(0xFFE0E0E0); bg = const Color(0xFFF5F5F7);
        ic = Icons.shield_outlined; title = 'Получите статус Verified';
        sub = 'Верифицированные продавцы получают больше доверия.';
        showBtn = _selectedType != SellerType.individual;
    }
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(16),
          border: Border.all(color: bc.withOpacity(0.4), width: 1.5)),
      child: Row(
        children: [
          Icon(ic, color: bc, size: 30),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontWeight: FontWeight.bold,
                    fontSize: 14, color: bc)),
                const SizedBox(height: 4),
                Text(sub, style: TextStyle(fontSize: 12,
                    color: Colors.grey[700], height: 1.4)),
                if (showBtn) ...[
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 34,
                    child: ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFF91155),
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8)),
                          padding: const EdgeInsets.symmetric(horizontal: 16)),
                      child: const Text('Подать заявку',
                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold,
                              color: Colors.white)),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _typeSelector() {
    final types = [
      (SellerType.individual, '👤', 'Частное лицо', 'Продаю своё'),
      (SellerType.shop, '🏪', 'Магазин / ИП', 'Торговля'),
      (SellerType.autoDismantle, '🔧', 'Авторазбор', 'Разборка'),
      (SellerType.dealer, '🏢', 'Дилер', 'Официальный'),
    ];
    return Container(
      decoration: BoxDecoration(color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05),
              blurRadius: 10, offset: const Offset(0, 2))]),
      padding: const EdgeInsets.all(12),
      child: GridView.count(
        crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10,
        shrinkWrap: true, childAspectRatio: 2.8,
        physics: const NeverScrollableScrollPhysics(),
        children: types.map((e) {
          final (type, icon, label, sub) = e;
          final sel = _selectedType == type;
          return GestureDetector(
            onTap: () => setState(() { _selectedType = type; _hasChanges = true; }),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                color: sel ? const Color(0xFFF91155).withOpacity(0.08)
                    : const Color(0xFFF5F5F7),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                    color: sel ? const Color(0xFFF91155) : const Color(0xFFE0E0E0),
                    width: sel ? 2 : 1),
              ),
              child: Row(
                children: [
                  Text(icon, style: const TextStyle(fontSize: 18)),
                  const SizedBox(width: 8),
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(label, style: TextStyle(fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: sel ? const Color(0xFFF91155) : Colors.black87)),
                      Text(sub, style: TextStyle(fontSize: 10, color: Colors.grey[500])),
                    ],
                  )),
                  if (sel) const Icon(Icons.check_circle,
                      color: Color(0xFFF91155), size: 16),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _infoCard() => _card([
        _field(_nameCtrl, 'Имя / Название', 'Ваше имя или название магазина'),
        const SizedBox(height: 16),
        _roField('Телефон', _profile.phone, Icons.lock_outline),
        const SizedBox(height: 16),
        _field(_cityCtrl, 'Город', 'Алматы, Астана...'),
      ]);

  Widget _bizCard() => _card([
        Text('Эти данные нужны для верификации',
            style: TextStyle(fontSize: 12, color: Colors.grey[600])),
        const SizedBox(height: 16),
        _field(_bizCtrl, 'Название организации', 'ИП Иванов / ТОО AutoParts'),
        const SizedBox(height: 16),
        _field(_binCtrl, 'БИН / ИИН', '123456789012',
            type: TextInputType.number),
      ]);

  Widget _card(List<Widget> children) => Container(
      decoration: BoxDecoration(color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05),
              blurRadius: 10, offset: const Offset(0, 2))]),
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children));

  Widget _field(TextEditingController c, String label, String hint,
      {TextInputType? type}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        TextField(
          controller: c, keyboardType: type,
          onChanged: (_) => setState(() => _hasChanges = true),
          decoration: InputDecoration(
            hintText: hint, filled: true, fillColor: const Color(0xFFF5F5F7),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: Color(0xFFF91155), width: 2)),
          ),
        ),
      ],
    );
  }

  Widget _roField(String label, String value, IconData icon) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(color: const Color(0xFFF5F5F7),
                borderRadius: BorderRadius.circular(12)),
            child: Row(children: [
              Expanded(child: Text(value,
                  style: TextStyle(fontSize: 15, color: Colors.grey[600]))),
              Icon(icon, size: 18, color: Colors.grey[400]),
            ]),
          ),
        ],
      );
}
