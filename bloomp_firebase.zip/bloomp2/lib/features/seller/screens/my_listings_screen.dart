import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import '../../../core/providers/auth_provider.dart';
import '../models/listing.dart';
import '../widgets/status_badge.dart';
import 'add_listing_screen.dart';

class MyListingsScreen extends StatefulWidget {
  const MyListingsScreen({super.key});

  @override
  State<MyListingsScreen> createState() => _MyListingsScreenState();
}

class _MyListingsScreenState extends State<MyListingsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final uid = context.read<AuthProvider>().uid;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F7),
      appBar: AppBar(
        title: const Text('Мои объявления',
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () => Navigator.pop(context)),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          labelColor: const Color(0xFFF91155),
          unselectedLabelColor: Colors.grey,
          indicatorColor: const Color(0xFFF91155),
          tabs: const [
            Tab(text: 'Все'), Tab(text: 'Активные'),
            Tab(text: 'На проверке'), Tab(text: 'Проданные'),
            Tab(text: 'Отклоненные'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildTab(uid, null),
          _buildTab(uid, ListingStatus.active),
          _buildTab(uid, ListingStatus.pending),
          _buildTab(uid, ListingStatus.sold),
          _buildTab(uid, ListingStatus.rejected),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const AddListingScreen())),
        backgroundColor: const Color(0xFFF91155),
        icon: const Icon(Icons.add),
        label: const Text('Добавить'),
      ),
    );
  }

  Widget _buildTab(String uid, ListingStatus? status) {
    Query<Map<String, dynamic>> query = FirebaseFirestore.instance
        .collection('listings')
        .where('sellerId', isEqualTo: uid)
        .orderBy('createdAt', descending: true);

    if (status != null) {
      query = query.where('status', isEqualTo: status.name);
    }

    return StreamBuilder<QuerySnapshot>(
      stream: query.snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
              child: CircularProgressIndicator(color: Color(0xFFF91155)));
        }

        // Используем mock данные если Firebase не настроен
        final docs = snapshot.data?.docs ?? [];

        if (docs.isEmpty) {
          return _buildEmpty();
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: docs.length,
          itemBuilder: (context, i) {
            final data = docs[i].data() as Map<String, dynamic>;
            return _buildCard(docs[i].id, data);
          },
        );
      },
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.inventory_2_outlined, size: 80, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Text('Нет объявлений',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600,
                  color: Colors.grey[700])),
          const SizedBox(height: 8),
          Text('Добавьте ваш первый товар',
              style: TextStyle(color: Colors.grey[500])),
        ],
      ),
    );
  }

  Widget _buildCard(String docId, Map<String, dynamic> data) {
    final status = ListingStatus.values.firstWhere(
        (s) => s.name == (data['status'] ?? 'draft'),
        orElse: () => ListingStatus.draft);
    final images = (data['images'] as List?)?.cast<String>() ?? [];
    final price = (data['price'] as num?)?.toDouble() ?? 0;
    final stock = (data['stock'] as num?)?.toInt() ?? 0;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05),
            blurRadius: 10, offset: const Offset(0, 2))],
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: images.isNotEmpty
                      ? Image.network(images.first, width: 100, height: 100,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => _imgPlaceholder())
                      : _imgPlaceholder(),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(data['name'] ?? '',
                          style: const TextStyle(fontSize: 14,
                              fontWeight: FontWeight.bold),
                          maxLines: 2, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 6),
                      Text('${price.toStringAsFixed(0)} ₸',
                          style: const TextStyle(fontSize: 17,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFFF91155))),
                      const SizedBox(height: 4),
                      Text(data['category'] ?? '',
                          style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          StatusBadge(status: status),
                          const SizedBox(width: 8),
                          Text(status == ListingStatus.sold
                              ? 'Продано' : '$stock шт.',
                              style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (data['rejectionReason'] != null)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                  color: Colors.red[50],
                  border: Border(top: BorderSide(color: Colors.red[200]!))),
              child: Row(
                children: [
                  const Icon(Icons.error_outline, color: Colors.red, size: 18),
                  const SizedBox(width: 8),
                  Expanded(child: Text('Причина: ${data['rejectionReason']}',
                      style: const TextStyle(color: Colors.red, fontSize: 12))),
                ],
              ),
            ),
          if (status != ListingStatus.sold)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                  border: Border(top: BorderSide(color: Colors.grey[200]!))),
              child: Row(
                children: [
                  if (status == ListingStatus.active ||
                      status == ListingStatus.rejected) ...[
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {},
                        icon: const Icon(Icons.edit, size: 16),
                        label: const Text('Редактировать'),
                        style: OutlinedButton.styleFrom(
                            foregroundColor: const Color(0xFF2E6FF2),
                            side: const BorderSide(color: Color(0xFF2E6FF2))),
                      ),
                    ),
                    const SizedBox(width: 8),
                  ],
                  if (status == ListingStatus.pending)
                    const Expanded(
                      child: Text('Ожидает проверки',
                          style: TextStyle(fontSize: 12, color: Colors.orange,
                              fontWeight: FontWeight.w600),
                          textAlign: TextAlign.center),
                    ),
                  if (status == ListingStatus.rejected)
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () => _resubmit(docId),
                        icon: const Icon(Icons.refresh, size: 16),
                        label: const Text('Повторить'),
                        style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFF91155)),
                      ),
                    ),
                  if (status == ListingStatus.active)
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _deactivate(docId),
                        icon: const Icon(Icons.pause, size: 16),
                        label: const Text('Снять'),
                        style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.orange,
                            side: const BorderSide(color: Colors.orange)),
                      ),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _imgPlaceholder() => Container(
      width: 100, height: 100,
      color: const Color(0xFFF5F5F7),
      child: const Icon(Icons.image, size: 40, color: Colors.grey));

  Future<void> _resubmit(String docId) async {
    await FirebaseFirestore.instance
        .collection('listings')
        .doc(docId)
        .update({'status': ListingStatus.pending.name, 'rejectionReason': null});
  }

  Future<void> _deactivate(String docId) async {
    await FirebaseFirestore.instance
        .collection('listings')
        .doc(docId)
        .update({'status': ListingStatus.draft.name});
  }
}
