import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:io';
import '../services/watermark_service.dart';
import '../models/listing.dart';
import '../../../core/providers/auth_provider.dart';
import 'package:path_provider/path_provider.dart';

class AddListingScreen extends StatefulWidget {
  const AddListingScreen({super.key});

  @override
  State<AddListingScreen> createState() => _AddListingScreenState();
}

class _AddListingScreenState extends State<AddListingScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _priceController = TextEditingController();
  final _oldPriceController = TextEditingController();
  final _stockController = TextEditingController(text: '1');
  final _partNumberController = TextEditingController();
  final _brandController = TextEditingController();

  final List<File> _images = [];
  final List<File> _processedImages = [];
  final List<String> _uploadedUrls = []; // URLs после Firebase upload
  bool _isProcessingImages = false;
  bool _isSubmitting = false;

  String? _selectedCategory;
  ListingCondition _condition = ListingCondition.brandNew;
  bool _isNegotiable = false;
  String? _selectedCarBrand;

  static const Color _primary = Color(0xFFF91155);

  final List<String> _categories = [
    'Масла', 'Фильтры', 'Тормоза', 'Шины',
    'Аккумуляторы', 'Свечи', 'Амортизаторы', 'Другое',
  ];

  final List<String> _carBrands = [
    'Toyota', 'BMW', 'Mercedes-Benz', 'Volkswagen',
    'Hyundai', 'Kia', 'Geely', 'Универсальное',
  ];

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _priceController.dispose();
    _oldPriceController.dispose();
    _stockController.dispose();
    _partNumberController.dispose();
    _brandController.dispose();
    super.dispose();
  }

  Future<void> _pickImages() async {
    if (_images.length >= 10) {
      _snack('Максимум 10 фотографий', Colors.red);
      return;
    }
    final picker = ImagePicker();
    final pickedFiles = await picker.pickMultiImage(
        maxWidth: 1920, maxHeight: 1920, imageQuality: 85);
    if (pickedFiles.isEmpty) return;

    final slots = 10 - _images.length;
    final skipped = pickedFiles.length > slots;

    setState(() => _isProcessingImages = true);

    for (var pf in pickedFiles) {
      if (_images.length >= 10) break;
      final file = File(pf.path);
      final result = await _processPhoto(file);

      if (result['success'] == true) {
        setState(() {
          _images.add(file);
          _processedImages.add(result['file'] as File);
          if (result['url'] != null) {
            _uploadedUrls.add(result['url'] as String);
          }
        });
      } else if (result['blocked'] == true && mounted) {
        _snack(result['error'] ?? 'Фото заблокировано', Colors.red);
      }
    }

    setState(() => _isProcessingImages = false);

    if (skipped && mounted) {
      _snack('Добавлено $slots из ${pickedFiles.length} фото — лимит 10 шт.', Colors.orange);
    }
  }

  Future<Map<String, dynamic>> _processPhoto(File imageFile) async {
    try {
      final appDir = await getApplicationDocumentsDirectory();
      final outputDir = '${appDir.path}/listings';
      await Directory(outputDir).create(recursive: true);
      return await WatermarkService.instance.processImage(imageFile, outputDir);
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }

  void _removeImage(int index) {
    setState(() {
      _images.removeAt(index);
      _processedImages.removeAt(index);
      if (index < _uploadedUrls.length) _uploadedUrls.removeAt(index);
    });
  }

  Future<void> _submitListing() async {
    if (!_formKey.currentState!.validate()) return;
    if (_images.isEmpty) { _snack('Добавьте хотя бы одно фото', Colors.red); return; }
    if (_selectedCategory == null) { _snack('Выберите категорию', Colors.red); return; }

    setState(() => _isSubmitting = true);

    try {
      final auth = context.read<AuthProvider>();
      final listing = Listing(
        id: '',
        sellerId: auth.uid,
        sellerName: auth.displayName,
        name: _nameController.text.trim(),
        description: _descriptionController.text.trim(),
        price: double.tryParse(_priceController.text) ?? 0,
        oldPrice: _oldPriceController.text.isNotEmpty
            ? double.tryParse(_oldPriceController.text)
            : null,
        category: _selectedCategory!,
        brand: _brandController.text.isNotEmpty ? _brandController.text.trim() : null,
        condition: _condition,
        images: _uploadedUrls,
        compatibleCarBrands: _selectedCarBrand != null ? [_selectedCarBrand!] : null,
        stock: int.tryParse(_stockController.text) ?? 1,
        status: ListingStatus.pending,
        partNumber: _partNumberController.text.isNotEmpty
            ? _partNumberController.text.trim()
            : null,
        isNegotiable: _isNegotiable,
        createdAt: DateTime.now(),
      );

      // Сохраняем в Firestore
      await FirebaseFirestore.instance
          .collection('listings')
          .add(listing.toFirestore());

      setState(() => _isSubmitting = false);

      if (mounted) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('✅ Успешно!'),
            content: const Text(
                'Ваше объявление отправлено на модерацию.\n\nМы проверим его в течение 24 часов.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                child: const Text('OK'),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      setState(() => _isSubmitting = false);
      _snack('Ошибка: $e', Colors.red);
    }
  }

  void _snack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg), backgroundColor: color,
            duration: const Duration(seconds: 3)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Добавить объявление',
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
            icon: const Icon(Icons.close, color: Colors.black),
            onPressed: () => Navigator.pop(context)),
        actions: [
          TextButton(
            onPressed: _isSubmitting ? null : _submitListing,
            child: _isSubmitting
                ? const SizedBox(width: 20, height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: _primary))
                : const Text('Опубликовать',
                    style: TextStyle(color: _primary,
                        fontWeight: FontWeight.bold, fontSize: 16)),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildPhotosSection(),
            const SizedBox(height: 24),
            _buildField(_nameController, 'Название товара', 'Масляный фильтр Toyota',
                validator: (v) => v!.isEmpty ? 'Введите название' : null),
            const SizedBox(height: 16),
            _buildDropdown('Категория', _selectedCategory, _categories,
                (v) => setState(() => _selectedCategory = v)),
            const SizedBox(height: 16),
            _buildField(_brandController, 'Бренд (опционально)', 'Mann, Bosch, NGK...'),
            const SizedBox(height: 16),
            _buildField(_partNumberController, 'Артикул (опционально)', 'C27009'),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(child: _buildField(_priceController, 'Цена', '5000',
                    type: TextInputType.number, suffix: const Text('₸'),
                    validator: (v) => v!.isEmpty ? 'Введите цену' : null)),
                const SizedBox(width: 16),
                Expanded(child: _buildField(_oldPriceController, 'Старая цена', '7000',
                    type: TextInputType.number, suffix: const Text('₸'))),
              ],
            ),
            const SizedBox(height: 16),
            _buildConditionSelector(),
            const SizedBox(height: 16),
            _buildField(_stockController, 'Количество', '1',
                type: TextInputType.number, suffix: const Text('шт.')),
            const SizedBox(height: 16),
            CheckboxListTile(
              value: _isNegotiable,
              onChanged: (v) => setState(() => _isNegotiable = v ?? false),
              title: const Text('Торг возможен'),
              activeColor: _primary,
              contentPadding: EdgeInsets.zero,
            ),
            const SizedBox(height: 24),
            const Text('Совместимость с авто',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildDropdown('Марка авто', _selectedCarBrand, _carBrands,
                (v) => setState(() => _selectedCarBrand = v)),
            const SizedBox(height: 24),
            _buildField(_descriptionController, 'Описание', 'Подробное описание...',
                maxLines: 5,
                validator: (v) => v!.isEmpty ? 'Введите описание' : null),
            const SizedBox(height: 32),
            SizedBox(
              height: 56,
              child: ElevatedButton(
                onPressed: _isSubmitting ? null : _submitListing,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _primary, foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                  elevation: 0,
                ),
                child: _isSubmitting
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text('Опубликовать объявление',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 16),
            _buildModerationInfo(),
          ],
        ),
      ),
    );
  }

  Widget _buildPhotosSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Фотографии',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text('${_images.length}/10',
                style: TextStyle(color: Colors.grey[600], fontSize: 14)),
          ],
        ),
        const SizedBox(height: 12),
        if (_isProcessingImages)
          Container(
            height: 120,
            decoration: BoxDecoration(color: const Color(0xFFF5F5F7),
                borderRadius: BorderRadius.circular(12)),
            child: const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: _primary),
                  SizedBox(height: 10),
                  Text('Проверка watermark и загрузка...'),
                ],
              ),
            ),
          )
        else
          SizedBox(
            height: 120,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                GestureDetector(
                  onTap: _pickImages,
                  child: Container(
                    width: 120,
                    margin: const EdgeInsets.only(right: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF5F5F7),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFFE0E0E0), width: 2),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.add_photo_alternate, size: 40, color: _primary),
                        const SizedBox(height: 8),
                        Text('Добавить',
                            style: TextStyle(color: Colors.grey[700], fontSize: 12)),
                      ],
                    ),
                  ),
                ),
                ..._processedImages.asMap().entries.map((e) {
                  final index = e.key;
                  final file = e.value;
                  return Container(
                    width: 120,
                    margin: const EdgeInsets.only(right: 12),
                    child: Stack(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.file(file, width: 120, height: 120,
                              fit: BoxFit.cover),
                        ),
                        Positioned(
                          top: 4, right: 4,
                          child: GestureDetector(
                            onTap: () => _removeImage(index),
                            child: Container(
                              padding: const EdgeInsets.all(4),
                              decoration: const BoxDecoration(
                                  color: Colors.red, shape: BoxShape.circle),
                              child: const Icon(Icons.close,
                                  color: Colors.white, size: 14),
                            ),
                          ),
                        ),
                        if (index == 0)
                          Positioned(
                            bottom: 4, left: 4,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(color: _primary,
                                  borderRadius: BorderRadius.circular(4)),
                              child: const Text('Главное',
                                  style: TextStyle(color: Colors.white,
                                      fontSize: 9, fontWeight: FontWeight.bold)),
                            ),
                          ),
                        // Индикатор загрузки в Firebase
                        if (index >= _uploadedUrls.length)
                          Positioned(
                            bottom: 4, right: 4,
                            child: Container(
                              width: 20, height: 20,
                              decoration: BoxDecoration(
                                  color: Colors.black54,
                                  borderRadius: BorderRadius.circular(10)),
                              child: const Center(
                                child: SizedBox(width: 12, height: 12,
                                    child: CircularProgressIndicator(
                                        strokeWidth: 2, color: Colors.white)),
                              ),
                            ),
                          ),
                      ],
                    ),
                  );
                }),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildField(
    TextEditingController controller,
    String label,
    String hint, {
    int maxLines = 1,
    TextInputType? type,
    Widget? suffix,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          maxLines: maxLines,
          keyboardType: type,
          validator: validator,
          decoration: InputDecoration(
            hintText: hint,
            suffixIcon: suffix != null
                ? Padding(padding: const EdgeInsets.only(right: 12), child: suffix)
                : null,
            suffixIconConstraints: const BoxConstraints(minWidth: 0, minHeight: 0),
            filled: true, fillColor: const Color(0xFFF5F5F7),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: _primary, width: 2)),
            errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: Colors.red, width: 2)),
          ),
        ),
      ],
    );
  }

  Widget _buildDropdown(String label, String? value, List<String> items,
      ValueChanged<String?> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(color: const Color(0xFFF5F5F7),
              borderRadius: BorderRadius.circular(12)),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value, isExpanded: true,
              hint: Text('Выберите $label'),
              items: items.map((i) => DropdownMenuItem(value: i, child: Text(i))).toList(),
              onChanged: onChanged,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildConditionSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Состояние',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(child: _condChip('Новое', ListingCondition.brandNew)),
            const SizedBox(width: 8),
            Expanded(child: _condChip('Б/у', ListingCondition.used)),
            const SizedBox(width: 8),
            Expanded(child: _condChip('Как новое', ListingCondition.likeNew)),
          ],
        ),
      ],
    );
  }

  Widget _condChip(String label, ListingCondition value) {
    final sel = _condition == value;
    return GestureDetector(
      onTap: () => setState(() => _condition = value),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: sel ? _primary : const Color(0xFFF5F5F7),
          borderRadius: BorderRadius.circular(12),
          border: sel ? null : Border.all(color: const Color(0xFFE0E0E0)),
        ),
        child: Text(label, textAlign: TextAlign.center,
            style: TextStyle(
                color: sel ? Colors.white : Colors.black87,
                fontWeight: sel ? FontWeight.bold : FontWeight.normal,
                fontSize: 14)),
      ),
    );
  }

  Widget _buildModerationInfo() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFFFFF0F5),
          borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(children: [
            Icon(Icons.info_outline, color: _primary),
            SizedBox(width: 8),
            Text('Модерация',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          ]),
          const SizedBox(height: 8),
          Text(
            'Ваше объявление будет проверено в течение 24 часов.\n\n'
            '• Фото проверяются AI на наличие чужих watermark\n'
            '• На одобренные фото добавляется watermark BLOOMP\n'
            '• Фото загружаются в облако Firebase Storage\n'
            '• Запрещено использовать фото с других сайтов',
            style: TextStyle(fontSize: 12, color: Colors.grey[700], height: 1.5),
          ),
        ],
      ),
    );
  }
}
