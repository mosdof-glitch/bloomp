import 'dart:io';
import 'package:image/image.dart' as img;
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../../config/gemini_config.dart';
import 'dart:convert';

class WatermarkService {
  static final WatermarkService _instance = WatermarkService._();
  static WatermarkService get instance => _instance;

  late GenerativeModel _visionModel;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  WatermarkService._() {
    _visionModel = GenerativeModel(
      model: GeminiConfig.visionModel,
      apiKey: GeminiConfig.apiKey,
    );
  }

  // ── ПРОВЕРКА ЧУЖИХ WATERMARK (Gemini Vision) ──────────────────
  Future<Map<String, dynamic>> checkForWatermarks(File imageFile) async {
    try {
      final bytes = await imageFile.readAsBytes();
      const prompt = '''
Проверь это изображение на наличие водяных знаков (watermark) или логотипов сайтов.
Особенно ищи: kolesa.kz, OLX.kz, Krisha.kz, Market.kz, Satu.kz, Avito

ВАЖНО: Отвечай ТОЛЬКО в формате JSON без markdown:
{
  "has_watermark": true,
  "source_website": "название сайта или null",
  "confidence": 0.95,
  "watermark_location": "где находится",
  "is_allowed": false
}
Если watermark нет: {"has_watermark": false, "is_allowed": true, "confidence": 0.99}
''';

      final content = [
        Content.multi([TextPart(prompt), DataPart('image/jpeg', bytes)])
      ];
      final response = await _visionModel.generateContent(content);
      return _parseJson(response.text ?? '');
    } catch (e) {
      // При ошибке AI разрешаем фото (fail-open)
      return {'has_watermark': false, 'is_allowed': true, 'error': e.toString()};
    }
  }

  // ── ДОБАВЛЕНИЕ BLOOMP WATERMARK ───────────────────────────────
  Future<File> addBloomWatermark(File imageFile, String outputPath) async {
    try {
      final bytes = await imageFile.readAsBytes();
      img.Image? image = img.decodeImage(bytes);
      if (image == null) return imageFile;

      final wh = (image.height * 0.08).toInt();
      final x = image.width - (image.width * 0.3).toInt();
      final y = image.height - wh - 20;

      img.fillRect(image,
          x1: x - 10, y1: y - 5,
          x2: image.width - 10, y2: y + wh + 5,
          color: img.ColorRgba8(0, 0, 0, 100));

      img.drawString(image, 'BLOOMP',
          font: img.arial48, x: x, y: y,
          color: img.ColorRgba8(255, 255, 255, 200));

      final output = File(outputPath);
      await output.writeAsBytes(img.encodeJpg(image, quality: 90));
      return output;
    } catch (e) {
      return imageFile;
    }
  }

  // ── ЗАГРУЗКА В FIREBASE STORAGE ───────────────────────────────
  Future<String?> uploadToFirebase(File imageFile) async {
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid ?? 'anonymous';
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final ref = _storage.ref('listings/$uid/bloomp_$timestamp.jpg');

      final task = await ref.putFile(
        imageFile,
        SettableMetadata(contentType: 'image/jpeg'),
      );

      return await task.ref.getDownloadURL();
    } catch (e) {
      return null;
    }
  }

  // ── ПОЛНЫЙ ПАЙПЛАЙН: проверка → watermark → upload ───────────
  Future<Map<String, dynamic>> processImage(
      File imageFile, String outputDir) async {
    try {
      // 1. Проверяем чужие watermark
      final check = await checkForWatermarks(imageFile);
      if (check['has_watermark'] == true && check['is_allowed'] == false) {
        return {
          'success': false,
          'blocked': true,
          'error': 'На фото обнаружен watermark от ${check['source_website'] ?? 'другого сайта'}',
        };
      }

      // 2. Накладываем BLOOMP watermark
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final processed = await addBloomWatermark(
          imageFile, '$outputDir/bloomp_$timestamp.jpg');

      // 3. Загружаем в Firebase Storage
      final url = await uploadToFirebase(processed);

      return {
        'success': true,
        'file': processed,
        'path': processed.path,
        'url': url, // null если Firebase не настроен
      };
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }

  Map<String, dynamic> _parseJson(String text) {
    try {
      text = text.replaceAll('```json', '').replaceAll('```', '').trim();
      final match = RegExp(r'\{[\s\S]*\}').firstMatch(text);
      if (match != null) return jsonDecode(match.group(0)!) as Map<String, dynamic>;
      return jsonDecode(text) as Map<String, dynamic>;
    } catch (_) {
      return {'has_watermark': false, 'is_allowed': true};
    }
  }
}
