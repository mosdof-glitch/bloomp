import 'package:flutter/material.dart';
import '../../../core/data/car_data.dart';

class CarSelection {
  final String? brand;
  final String? model;
  final String? year;
  final String? bodyType;

  const CarSelection({this.brand, this.model, this.year, this.bodyType});

  bool get isEmpty =>
      brand == null && model == null && year == null && bodyType == null;

  String get summary {
    final parts = [brand, model, year, bodyType]
        .where((p) => p != null)
        .toList();
    return parts.isEmpty ? 'Выберите автомобиль' : parts.join(' · ');
  }

  CarSelection copyWith({
    String? brand, String? model, String? year, String? bodyType,
  }) =>
      CarSelection(
        brand: brand ?? this.brand,
        model: model ?? this.model,
        year: year ?? this.year,
        bodyType: bodyType ?? this.bodyType,
      );

  CarSelection resetFrom(String field) {
    switch (field) {
      case 'brand':
        return const CarSelection();
      case 'model':
        return CarSelection(brand: brand);
      case 'year':
        return CarSelection(brand: brand, model: model);
      default:
        return this;
    }
  }
}

class CarSelectorWidget extends StatefulWidget {
  final CarSelection selection;
  final ValueChanged<CarSelection> onChanged;

  const CarSelectorWidget({
    super.key,
    required this.selection,
    required this.onChanged,
  });

  @override
  State<CarSelectorWidget> createState() => _CarSelectorWidgetState();
}

class _CarSelectorWidgetState extends State<CarSelectorWidget> {
  static const Color _primary = Color(0xFFF91155);
  static const Color _bg = Color(0xFFF5F5F7);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 2)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Подбор по автомобилю',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                ),
                if (!widget.selection.isEmpty)
                  GestureDetector(
                    onTap: () => widget.onChanged(const CarSelection()),
                    child: const Text(
                      'Сбросить',
                      style: TextStyle(
                          fontSize: 13,
                          color: _primary,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
              ],
            ),
          ),

          // МАРКА
          _buildSelector(
            label: 'Марка',
            value: widget.selection.brand,
            hint: 'Выберите марку',
            icon: Icons.directions_car_outlined,
            onTap: () => _showPicker(
              context: context,
              title: 'Выберите марку',
              items: CarData.brands,
              onSelected: (v) => widget.onChanged(
                widget.selection.resetFrom('brand').copyWith(brand: v),
              ),
            ),
          ),

          // МОДЕЛЬ (только если выбрана марка)
          AnimatedCrossFade(
            duration: const Duration(milliseconds: 200),
            crossFadeState: widget.selection.brand != null
                ? CrossFadeState.showSecond
                : CrossFadeState.showFirst,
            firstChild: const SizedBox.shrink(),
            secondChild: _buildSelector(
              label: 'Модель',
              value: widget.selection.model,
              hint: 'Выберите модель',
              icon: Icons.tune_rounded,
              onTap: () => _showPicker(
                context: context,
                title: 'Выберите модель',
                items: CarData.getModels(widget.selection.brand ?? ''),
                onSelected: (v) => widget.onChanged(
                  widget.selection.resetFrom('model').copyWith(model: v),
                ),
              ),
            ),
          ),

          // ГОД
          AnimatedCrossFade(
            duration: const Duration(milliseconds: 200),
            crossFadeState: widget.selection.model != null
                ? CrossFadeState.showSecond
                : CrossFadeState.showFirst,
            firstChild: const SizedBox.shrink(),
            secondChild: _buildSelector(
              label: 'Год выпуска',
              value: widget.selection.year,
              hint: 'Выберите год',
              icon: Icons.calendar_today_outlined,
              onTap: () => _showPicker(
                context: context,
                title: 'Выберите год',
                items: CarData.years,
                onSelected: (v) => widget.onChanged(
                  widget.selection.copyWith(year: v),
                ),
              ),
            ),
          ),

          // КУЗОВ
          AnimatedCrossFade(
            duration: const Duration(milliseconds: 200),
            crossFadeState: widget.selection.year != null
                ? CrossFadeState.showSecond
                : CrossFadeState.showFirst,
            firstChild: const SizedBox.shrink(),
            secondChild: _buildSelector(
              label: 'Кузов',
              value: widget.selection.bodyType,
              hint: 'Выберите тип кузова',
              icon: Icons.car_repair_outlined,
              onTap: () => _showPicker(
                context: context,
                title: 'Тип кузова',
                items: CarData.bodyTypes,
                onSelected: (v) => widget.onChanged(
                  widget.selection.copyWith(bodyType: v),
                ),
              ),
              isLast: true,
            ),
          ),

          // КНОПКА НАЙТИ (если выбрано хотя бы одно поле)
          if (!widget.selection.isEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
              child: SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _primary,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    elevation: 0,
                  ),
                  child: Text(
                    'Найти запчасти для ${widget.selection.brand ?? "авто"}',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                ),
              ),
            )
          else
            const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _buildSelector({
    required String label,
    required String? value,
    required String hint,
    required IconData icon,
    required VoidCallback onTap,
    bool isLast = false,
  }) {
    final isSelected = value != null;

    return Column(
      children: [
        const Divider(height: 1, indent: 16, endIndent: 16),
        InkWell(
          onTap: onTap,
          borderRadius: isLast
              ? const BorderRadius.only(
                  bottomLeft: Radius.circular(16),
                  bottomRight: Radius.circular(16))
              : BorderRadius.zero,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: isSelected
                        ? _primary.withOpacity(0.1)
                        : _bg,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon,
                      size: 18,
                      color: isSelected ? _primary : Colors.grey[500]),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(label,
                          style: TextStyle(
                              fontSize: 11,
                              color: Colors.grey[500],
                              fontWeight: FontWeight.w500)),
                      const SizedBox(height: 2),
                      Text(
                        value ?? hint,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: isSelected
                              ? FontWeight.w600
                              : FontWeight.normal,
                          color: isSelected
                              ? const Color(0xFF1A1A1A)
                              : Colors.grey[400],
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  isSelected
                      ? Icons.check_circle
                      : Icons.chevron_right_rounded,
                  color: isSelected ? _primary : Colors.grey[400],
                  size: 22,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  void _showPicker({
    required BuildContext context,
    required String title,
    required List<String> items,
    required ValueChanged<String> onSelected,
  }) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _PickerSheet(
        title: title,
        items: items,
        onSelected: (v) {
          Navigator.pop(context);
          onSelected(v);
        },
      ),
    );
  }
}

class _PickerSheet extends StatefulWidget {
  final String title;
  final List<String> items;
  final ValueChanged<String> onSelected;

  const _PickerSheet({
    required this.title,
    required this.items,
    required this.onSelected,
  });

  @override
  State<_PickerSheet> createState() => _PickerSheetState();
}

class _PickerSheetState extends State<_PickerSheet> {
  String _search = '';
  late List<String> _filtered;

  @override
  void initState() {
    super.initState();
    _filtered = widget.items;
  }

  void _onSearch(String query) {
    setState(() {
      _search = query;
      _filtered = widget.items
          .where((i) => i.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.75,
      maxChildSize: 0.95,
      minChildSize: 0.4,
      builder: (context, scrollController) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          children: [
            // Handle
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2)),
              ),
            ),
            const SizedBox(height: 16),

            // Title
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(widget.title,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 12),

            // Search
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                onChanged: _onSearch,
                decoration: InputDecoration(
                  hintText: 'Поиск...',
                  prefixIcon: const Icon(Icons.search, color: Colors.grey),
                  filled: true,
                  fillColor: const Color(0xFFF5F5F7),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none),
                ),
              ),
            ),
            const SizedBox(height: 8),

            // List
            Expanded(
              child: ListView.builder(
                controller: scrollController,
                itemCount: _filtered.length,
                itemBuilder: (context, index) {
                  final item = _filtered[index];
                  return ListTile(
                    title: Text(item),
                    onTap: () => widget.onSelected(item),
                    trailing: const Icon(Icons.chevron_right_rounded,
                        color: Colors.grey),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
