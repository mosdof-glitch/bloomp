import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/providers/auth_provider.dart';
import '../../../core/providers/cart_provider.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  static const Color _primary = Color(0xFFF91155);

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final cart = context.watch<CartProvider>();

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F7),
      body: CustomScrollView(
        slivers: [
          // HEADER
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            backgroundColor: _primary,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFFF91155), Color(0xFFD30A4A)],
                  ),
                ),
                child: SafeArea(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 20),
                      // АВАТАР
                      CircleAvatar(
                        radius: 40,
                        backgroundColor: Colors.white,
                        backgroundImage: auth.photoUrl != null
                            ? NetworkImage(auth.photoUrl!)
                            : null,
                        child: auth.photoUrl == null
                            ? const Icon(Icons.person,
                                size: 40, color: _primary)
                            : null,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        auth.displayName,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        auth.email,
                        style: TextStyle(
                            color: Colors.white.withOpacity(0.8),
                            fontSize: 14),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // STATS ROW
                  Row(
                    children: [
                      Expanded(child: _statCard(
                          '${cart.itemCount}', 'В корзине', Icons.shopping_cart_outlined)),
                      const SizedBox(width: 12),
                      Expanded(child: _statCard('0', 'Заказов', Icons.receipt_outlined)),
                      const SizedBox(width: 12),
                      Expanded(child: _statCard('0', 'Избранных', Icons.favorite_outline)),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // МЕНЮ
                  _menuSection('Мои данные', [
                    _menuItem(Icons.person_outline, 'Личные данные', onTap: () {}),
                    _menuItem(Icons.location_on_outlined, 'Адреса доставки', onTap: () {}),
                    _menuItem(Icons.notifications_outlined, 'Уведомления', onTap: () {}),
                  ]),
                  const SizedBox(height: 12),

                  _menuSection('Покупки', [
                    _menuItem(Icons.receipt_long_outlined, 'История заказов', onTap: () {}),
                    _menuItem(Icons.favorite_outline, 'Избранное', onTap: () {}),
                    _menuItem(Icons.star_outline_rounded, 'Мои отзывы', onTap: () {}),
                  ]),
                  const SizedBox(height: 12),

                  _menuSection('Помощь', [
                    _menuItem(Icons.help_outline, 'Поддержка', onTap: () {}),
                    _menuItem(Icons.info_outline, 'О приложении', onTap: () {}),
                  ]),
                  const SizedBox(height: 12),

                  // ВЫХОД
                  Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 8,
                              offset: const Offset(0, 2))
                        ]),
                    child: ListTile(
                      leading: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                            color: Colors.red[50],
                            borderRadius: BorderRadius.circular(10)),
                        child: const Icon(Icons.logout, color: Colors.red, size: 20),
                      ),
                      title: const Text('Выйти',
                          style: TextStyle(
                              color: Colors.red, fontWeight: FontWeight.w600)),
                      trailing: const Icon(Icons.chevron_right, color: Colors.red),
                      onTap: () => _confirmSignOut(context, auth),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _statCard(String value, String label, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 8,
                offset: const Offset(0, 2))
          ]),
      child: Column(
        children: [
          Icon(icon, color: _primary, size: 24),
          const SizedBox(height: 6),
          Text(value,
              style: const TextStyle(
                  fontSize: 22, fontWeight: FontWeight.bold)),
          Text(label,
              style:
                  TextStyle(fontSize: 11, color: Colors.grey[600])),
        ],
      ),
    );
  }

  Widget _menuSection(String title, List<Widget> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(title,
              style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF6B7280))),
        ),
        Container(
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 2))
              ]),
          child: Column(children: items),
        ),
      ],
    );
  }

  Widget _menuItem(IconData icon, String title,
      {required VoidCallback onTap, Color? color}) {
    return ListTile(
      leading: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
            color: (color ?? _primary).withOpacity(0.08),
            borderRadius: BorderRadius.circular(10)),
        child: Icon(icon, color: color ?? _primary, size: 20),
      ),
      title: Text(title,
          style: TextStyle(
              fontWeight: FontWeight.w500,
              color: color ?? const Color(0xFF1A1A1A))),
      trailing: const Icon(Icons.chevron_right, color: Colors.grey),
      onTap: onTap,
    );
  }

  void _confirmSignOut(BuildContext context, AuthProvider auth) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Выйти из аккаунта?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Отмена')),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              auth.signOut();
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Выйти'),
          ),
        ],
      ),
    );
  }
}
