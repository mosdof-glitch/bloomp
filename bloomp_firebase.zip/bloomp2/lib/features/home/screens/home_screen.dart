import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/wb_theme.dart';
import '../../../core/data/mock_products.dart';
import '../../../core/providers/cart_provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchController = TextEditingController();
  final String _currentAddress = 'Алматы';
  static const Color _primary = Color(0xFFF91155);

  @override
  void dispose() { _searchController.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final products = MockData.getProducts();
    return Scaffold(
      backgroundColor: WBTheme.wbBg,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(child: _buildHeader(context)),
          SliverPadding(
            padding: const EdgeInsets.only(top: 8),
            sliver: SliverToBoxAdapter(child: _buildBanner()),
          ),
          SliverToBoxAdapter(child: _buildMyGarage()),
          SliverToBoxAdapter(child: _buildServiceIcons()),
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Text('Рекомендуем вам',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold,
                      letterSpacing: -0.5)),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, childAspectRatio: 0.72,
                mainAxisSpacing: 8, crossAxisSpacing: 8,
              ),
              delegate: SliverChildBuilderDelegate(
                (context, index) => _buildCard(products[index]),
                childCount: products.length,
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 30)),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFF91155), Color(0xFFD30A4A)]),
        borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(20), bottomRight: Radius.circular(20)),
      ),
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, top + 5, 16, 15),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(children: [
                  const Icon(Icons.location_on, size: 18, color: Colors.white),
                  const SizedBox(width: 4),
                  Text(_currentAddress, style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w500)),
                  const Icon(Icons.keyboard_arrow_down, size: 18, color: Colors.white),
                ]),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(color: Colors.black,
                      borderRadius: BorderRadius.circular(8)),
                  child: const Text('Войти', style: TextStyle(
                      color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              height: 40,
              decoration: BoxDecoration(color: Colors.white,
                  borderRadius: BorderRadius.circular(10)),
              child: TextField(
                controller: _searchController,
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  hintText: 'Искать на Bloomp',
                  hintStyle: TextStyle(color: Colors.grey.withOpacity(0.6), fontSize: 14),
                  prefixIcon: const Icon(Icons.search, color: Colors.grey, size: 20),
                  border: InputBorder.none,
                ),
              ),
            ),
            const SizedBox(height: 15),
            Container(
              height: 90, width: double.infinity,
              decoration: BoxDecoration(color: Colors.white.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(15)),
              child: const Center(child: Text('РЕКЛАМНЫЙ БАННЕР',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBanner() {
    return AspectRatio(
      aspectRatio: 2.8,
      child: PageView.builder(
        itemCount: 3,
        itemBuilder: (context, i) => Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            gradient: const LinearGradient(
                colors: [Color(0xFF8E2DE2), Color(0xFF4A00E0)]),
          ),
          child: Center(child: Text('АКЦИЯ ${i + 1}',
              style: const TextStyle(color: Colors.white,
                  fontWeight: FontWeight.bold, fontSize: 18))),
        ),
      ),
    );
  }

  Widget _buildMyGarage() {
    return Container(
      height: 85,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03),
            blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.black, width: 1.2),
                      borderRadius: BorderRadius.circular(3)),
                  child: const Text('001 ABC | 02',
                      style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900)),
                ),
                const SizedBox(width: 12),
                const Text('Geely Atlas Pro',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
              ]),
              const Text('ТО через 1 200 км',
                  style: TextStyle(color: Colors.pink,
                      fontWeight: FontWeight.bold, fontSize: 11)),
            ],
          ),
          const Spacer(),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: const LinearProgressIndicator(value: 0.8, minHeight: 4,
                valueColor: AlwaysStoppedAnimation<Color>(Colors.pink),
                backgroundColor: Color(0xFFF5F5F5)),
          ),
        ],
      ),
    );
  }

  Widget _buildServiceIcons() {
    final services = [
      {'title': 'Каталог', 'icon': Icons.apps_rounded, 'color': Colors.purple},
      {'title': 'СТО', 'icon': Icons.build_circle_outlined, 'color': Colors.deepPurple},
      {'title': 'Мойка', 'icon': Icons.local_car_wash_rounded, 'color': Colors.pink},
      {'title': 'Штрафы', 'icon': Icons.policy_outlined, 'color': Colors.indigo},
      {'title': 'Масло', 'icon': Icons.oil_barrel_outlined, 'color': Colors.blue},
    ];
    return SizedBox(
      height: 100,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: services.length,
        itemBuilder: (context, i) {
          final s = services[i];
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircleAvatar(
                  radius: 28, backgroundColor: Colors.white,
                  child: Icon(s['icon'] as IconData,
                      color: s['color'] as Color, size: 28),
                ),
                const SizedBox(height: 6),
                Text(s['title'] as String,
                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildCard(MockProduct product) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05),
            blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Stack(
              children: [
                Container(
                  decoration: const BoxDecoration(color: Color(0xFFF5F5F7),
                      borderRadius: BorderRadius.vertical(top: Radius.circular(14))),
                  width: double.infinity,
                  child: const Center(child: Icon(Icons.image, size: 48, color: Colors.grey)),
                ),
                Positioned(
                  top: 8, right: 8,
                  child: Container(
                    width: 30, height: 30,
                    decoration: BoxDecoration(color: Colors.white,
                        shape: BoxShape.circle, boxShadow: [
                          BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 4)
                        ]),
                    child: const Icon(Icons.favorite_border, size: 16, color: Colors.grey),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (product.brand != null)
                  Text(product.brand!, style: TextStyle(fontSize: 11,
                      color: Colors.grey[500], fontWeight: FontWeight.w500)),
                const SizedBox(height: 2),
                Text(product.name, style: const TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w600),
                    maxLines: 2, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 6),
                if (product.oldPrice != null)
                  Text('${product.oldPrice!.toStringAsFixed(0)} ₸',
                      style: const TextStyle(fontSize: 11, color: Colors.grey,
                          decoration: TextDecoration.lineThrough)),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('${product.price.toStringAsFixed(0)} ₸',
                        style: const TextStyle(fontSize: 15,
                            fontWeight: FontWeight.bold, color: _primary)),
                    GestureDetector(
                      onTap: () {
                        context.read<CartProvider>().addItem(CartItem(
                          id: '', productId: product.id, name: product.name,
                          price: product.price, imageUrl: product.imageUrl,
                          brand: product.brand, sellerName: product.sellerName,
                        ));
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('${product.name} добавлен в корзину'),
                              backgroundColor: Colors.green,
                              duration: const Duration(seconds: 2)),
                        );
                      },
                      child: Container(
                        width: 30, height: 30,
                        decoration: BoxDecoration(color: _primary,
                            borderRadius: BorderRadius.circular(8)),
                        child: const Icon(Icons.add, color: Colors.white, size: 18),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
