class MockProduct {
  final String id;
  final String name;
  final double price;
  final double? oldPrice;
  final String category;
  final String? brand;
  final String imageUrl;
  final String? sellerName;

  const MockProduct({
    required this.id,
    required this.name,
    required this.price,
    this.oldPrice,
    required this.category,
    this.brand,
    required this.imageUrl,
    this.sellerName,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'price': price,
        'oldPrice': oldPrice,
        'category': category,
        'brand': brand,
        'imageUrl': imageUrl,
        'sellerName': sellerName,
      };
}

class MockData {
  static List<MockProduct> getProducts() => [
        const MockProduct(id: '1', name: 'Масляный фильтр Toyota Camry',
            price: 4150, oldPrice: 5500, category: 'Фильтры', brand: 'Toyota',
            imageUrl: 'https://via.placeholder.com/300', sellerName: 'Автозапчасти PRO'),
        const MockProduct(id: '2', name: 'Тормозные колодки Brembo P83',
            price: 12000, category: 'Тормоза', brand: 'Brembo',
            imageUrl: 'https://via.placeholder.com/300', sellerName: 'BremboKZ'),
        const MockProduct(id: '3', name: 'Свечи зажигания NGK Iridium',
            price: 2400, oldPrice: 3200, category: 'Свечи', brand: 'NGK',
            imageUrl: 'https://via.placeholder.com/300', sellerName: 'NGK Official'),
        const MockProduct(id: '4', name: 'Воздушный фильтр Mann C27009',
            price: 3500, category: 'Фильтры', brand: 'Mann',
            imageUrl: 'https://via.placeholder.com/300', sellerName: 'FilterShop'),
        const MockProduct(id: '5', name: 'Аккумулятор Varta Blue 60Ah',
            price: 45000, oldPrice: 52000, category: 'Аккумуляторы', brand: 'Varta',
            imageUrl: 'https://via.placeholder.com/300', sellerName: 'Varta KZ'),
        const MockProduct(id: '6', name: 'Моторное масло Castrol 5W-30',
            price: 8500, oldPrice: 9900, category: 'Масла', brand: 'Castrol',
            imageUrl: 'https://via.placeholder.com/300', sellerName: 'OilShop'),
        const MockProduct(id: '7', name: 'Амортизатор KYB задний',
            price: 18000, category: 'Амортизаторы', brand: 'KYB',
            imageUrl: 'https://via.placeholder.com/300', sellerName: 'KYB Parts'),
        const MockProduct(id: '8', name: 'Ремень ГРМ Gates',
            price: 8900, category: 'Ремни', brand: 'Gates',
            imageUrl: 'https://via.placeholder.com/300', sellerName: 'AutoParts'),
      ];
}
