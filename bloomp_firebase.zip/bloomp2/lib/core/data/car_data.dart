class CarData {
  // Марки авто
  static const List<String> brands = [
    'Toyota', 'Hyundai', 'Kia', 'Chevrolet', 'Geely',
    'Lada', 'BMW', 'Mercedes-Benz', 'Audi', 'Volkswagen',
    'Lexus', 'Honda', 'Nissan', 'Mitsubishi', 'Mazda',
    'Subaru', 'Suzuki', 'Ford', 'Skoda', 'Haval',
    'Chery', 'JAC', 'BYD', 'Great Wall', 'Lifan',
  ];

  // Модели по маркам
  static const Map<String, List<String>> modelsByBrand = {
    'Toyota': ['Camry', 'Corolla', 'RAV4', 'Land Cruiser', 'Prado', 'Hilux', 'Yaris', 'Fortuner'],
    'Hyundai': ['Sonata', 'Elantra', 'Tucson', 'Santa Fe', 'Accent', 'Creta', 'Solaris', 'i30'],
    'Kia': ['K5', 'Sportage', 'Cerato', 'Sorento', 'Rio', 'Seltos', 'Carnival', 'Stinger'],
    'Chevrolet': ['Malibu', 'Cruze', 'Captiva', 'Cobalt', 'Nexia', 'Lacetti', 'TrailBlazer'],
    'Geely': ['Atlas', 'Coolray', 'Emgrand', 'Tugella', 'Okavango', 'Monjaro', 'Atlas Pro'],
    'Lada': ['Granta', 'Vesta', 'Niva', 'Priora', 'Kalina', 'XRAY', 'Largus'],
    'BMW': ['3 Series', '5 Series', '7 Series', 'X3', 'X5', 'X6', 'X7', '1 Series'],
    'Mercedes-Benz': ['C-Class', 'E-Class', 'S-Class', 'GLE', 'GLC', 'GLS', 'A-Class'],
    'Audi': ['A4', 'A6', 'A8', 'Q5', 'Q7', 'Q8', 'A3', 'Q3'],
    'Volkswagen': ['Passat', 'Golf', 'Tiguan', 'Touareg', 'Polo', 'Jetta', 'Teramont'],
    'Lexus': ['RX', 'LX', 'GX', 'ES', 'IS', 'LS', 'NX', 'UX'],
    'Honda': ['Accord', 'Civic', 'CR-V', 'Pilot', 'HR-V', 'Jazz', 'Odyssey'],
    'Nissan': ['Qashqai', 'X-Trail', 'Patrol', 'Pathfinder', 'Juke', 'Murano', 'Teana'],
    'Mitsubishi': ['Outlander', 'Pajero', 'Eclipse Cross', 'ASX', 'L200', 'Galant'],
    'Mazda': ['CX-5', 'CX-9', 'Mazda 3', 'Mazda 6', 'CX-3', 'MX-5'],
    'Subaru': ['Forester', 'Outback', 'XV', 'Legacy', 'Impreza', 'Ascent'],
    'Suzuki': ['Vitara', 'Grand Vitara', 'Jimny', 'Swift', 'SX4', 'Baleno'],
    'Ford': ['Focus', 'Mondeo', 'Explorer', 'Kuga', 'EcoSport', 'Ranger', 'F-150'],
    'Skoda': ['Octavia', 'Superb', 'Kodiaq', 'Karoq', 'Rapid', 'Fabia'],
    'Haval': ['H6', 'H9', 'F7', 'Jolion', 'Dargo', 'H2'],
    'Chery': ['Tiggo 4', 'Tiggo 7', 'Tiggo 8', 'Arrizo 5', 'Arrizo 8'],
    'JAC': ['J7', 'S7', 'T8', 'T6', 'S4', 'JS4'],
    'BYD': ['Han', 'Tang', 'Song', 'Atto 3', 'Seal', 'Dolphin'],
    'Great Wall': ['Wingle', 'Hover H5', 'Peri'],
    'Lifan': ['X60', 'X70', 'Myway', 'Smily'],
  };

  // Кузов
  static const List<String> bodyTypes = [
    'Седан',
    'Внедорожник / SUV',
    'Хэтчбек',
    'Универсал',
    'Купе',
    'Минивэн',
    'Пикап',
    'Кабриолет',
    'Лифтбек',
    'Кроссовер',
  ];

  // Диапазон годов
  static List<String> get years {
    final currentYear = DateTime.now().year;
    return List.generate(currentYear - 1989, (i) => (currentYear - i).toString());
  }

  static List<String> getModels(String brand) {
    return modelsByBrand[brand] ?? [];
  }
}
