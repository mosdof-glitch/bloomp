import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class CartItem {
  final String id;
  final String productId;
  final String name;
  final double price;
  final String imageUrl;
  final String? brand;
  final String? sellerName;
  int quantity;

  CartItem({
    required this.id,
    required this.productId,
    required this.name,
    required this.price,
    required this.imageUrl,
    this.brand,
    this.sellerName,
    this.quantity = 1,
  });

  Map<String, dynamic> toMap() => {
        'productId': productId,
        'name': name,
        'price': price,
        'imageUrl': imageUrl,
        'brand': brand,
        'sellerName': sellerName,
        'quantity': quantity,
        'updatedAt': FieldValue.serverTimestamp(),
      };

  factory CartItem.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return CartItem(
      id: doc.id,
      productId: data['productId'] ?? '',
      name: data['name'] ?? '',
      price: (data['price'] as num).toDouble(),
      imageUrl: data['imageUrl'] ?? '',
      brand: data['brand'],
      sellerName: data['sellerName'],
      quantity: data['quantity'] ?? 1,
    );
  }
}

class CartProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  List<CartItem> _items = [];
  bool _isLoading = false;
  String? _error;

  List<CartItem> get items => List.unmodifiable(_items);
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isEmpty => _items.isEmpty;

  int get itemCount => _items.fold(0, (sum, item) => sum + item.quantity);

  double get totalPrice =>
      _items.fold(0.0, (sum, item) => sum + item.price * item.quantity);

  String? get _userId => _auth.currentUser?.uid;

  CollectionReference? get _cartRef => _userId != null
      ? _firestore.collection('carts').doc(_userId).collection('items')
      : null;

  // Загрузить корзину из Firestore
  Future<void> loadCart() async {
    if (_cartRef == null) return;
    try {
      _isLoading = true;
      notifyListeners();

      final snapshot = await _cartRef!.get();
      _items = snapshot.docs.map((doc) => CartItem.fromFirestore(doc)).toList();

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  // Слушать корзину в реальном времени
  void listenToCart() {
    if (_cartRef == null) return;
    _cartRef!.snapshots().listen((snapshot) {
      _items = snapshot.docs.map((doc) => CartItem.fromFirestore(doc)).toList();
      notifyListeners();
    });
  }

  // Добавить товар
  Future<void> addItem(CartItem item) async {
    try {
      // Проверяем — товар уже в корзине?
      final existing = _items.where((i) => i.productId == item.productId).toList();

      if (existing.isNotEmpty) {
        // Увеличиваем количество
        await incrementQuantity(existing.first.id);
      } else {
        // Добавляем новый
        if (_cartRef != null) {
          await _cartRef!.add(item.toMap());
        } else {
          // Гость — храним локально
          _items.add(item);
          notifyListeners();
        }
      }
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  // Увеличить количество
  Future<void> incrementQuantity(String itemId) async {
    final index = _items.indexWhere((i) => i.id == itemId);
    if (index == -1) return;

    _items[index].quantity++;
    notifyListeners();

    if (_cartRef != null) {
      await _cartRef!.doc(itemId).update({'quantity': _items[index].quantity});
    }
  }

  // Уменьшить количество
  Future<void> decrementQuantity(String itemId) async {
    final index = _items.indexWhere((i) => i.id == itemId);
    if (index == -1) return;

    if (_items[index].quantity <= 1) {
      await removeItem(itemId);
    } else {
      _items[index].quantity--;
      notifyListeners();

      if (_cartRef != null) {
        await _cartRef!.doc(itemId).update({'quantity': _items[index].quantity});
      }
    }
  }

  // Удалить товар
  Future<void> removeItem(String itemId) async {
    _items.removeWhere((i) => i.id == itemId);
    notifyListeners();

    if (_cartRef != null) {
      await _cartRef!.doc(itemId).delete();
    }
  }

  // Очистить корзину
  Future<void> clearCart() async {
    if (_cartRef != null) {
      final batch = _firestore.batch();
      for (final item in _items) {
        batch.delete(_cartRef!.doc(item.id));
      }
      await batch.commit();
    }
    _items.clear();
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
