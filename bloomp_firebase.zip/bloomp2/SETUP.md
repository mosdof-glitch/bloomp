# BLOOMP — Инструкция по настройке

## 1. Создай Flutter проект

```bash
flutter create bloomp
cd bloomp
```

Скопируй все файлы из этого архива в папку bloomp (заменяй существующие).

## 2. Настройка Firebase (обязательно)

### 2а. Создай Firebase проект
1. Перейди на https://console.firebase.google.com
2. Создай новый проект "bloomp"
3. Включи **Authentication → Google Sign-In**
4. Включи **Firestore Database** (режим test на старте)
5. Включи **Storage**

### 2б. Установи FlutterFire CLI
```bash
dart pub global activate flutterfire_cli
```

### 2в. Настрой Firebase в проекте
```bash
flutterfire configure
```
Выбери свой проект. Команда создаст `lib/firebase_options.dart` — **замени** существующий файл-заглушку.

### 2г. Android — добавь SHA-1 для Google Sign-In
```bash
cd android && ./gradlew signingReport
```
Скопируй SHA-1 и добавь в Firebase Console → Project Settings → Your Apps → Android app.

### 2д. Для iOS — добавь GoogleService-Info.plist
Скачай из Firebase Console и помести в `ios/Runner/`.

## 3. Настройка .env
```bash
cp .env.example .env
```
Открой `.env` и добавь Gemini API ключ:
```
GEMINI_API_KEY=твой_ключ_здесь
```
Получить ключ: https://makersuite.google.com/app/apikey

## 4. Firestore — правила безопасности
В Firebase Console → Firestore → Rules:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Корзина — только владелец
    match /carts/{userId}/items/{itemId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    // Объявления — читать всем, писать только авторизованным
    match /listings/{listingId} {
      allow read: if true;
      allow create: if request.auth != null;
      allow update, delete: if request.auth != null
        && request.auth.uid == resource.data.sellerId;
    }
  }
}
```

## 5. Firebase Storage — правила
```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /listings/{userId}/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

## 6. Установи зависимости и запусти
```bash
flutter pub get
flutter run
```

## Структура проекта
```
lib/
├── firebase_options.dart     ← заменить через flutterfire configure
├── main.dart
├── main_navigator.dart
├── config/
│   └── gemini_config.dart
├── core/
│   ├── theme/
│   ├── data/
│   │   ├── car_data.dart       ← 25 марок, модели, года, кузов
│   │   └── mock_products.dart
│   └── providers/
│       ├── auth_provider.dart  ← Google Auth
│       └── cart_provider.dart  ← Firebase Firestore
├── features/
│   ├── auth/screens/auth_screen.dart         ← Google Sign In
│   ├── home/screens/home_screen.dart
│   ├── catalog/
│   │   ├── screens/catalog_screen.dart       ← фильтры + авто
│   │   └── widgets/car_selector_widget.dart  ← марка/год/модель/кузов
│   ├── cart/screens/cart_screen.dart         ← Firebase корзина
│   ├── profile/screens/profile_screen.dart
│   └── seller/
│       ├── models/
│       ├── services/watermark_service.dart   ← Gemini + Firebase Storage
│       ├── widgets/status_badge.dart
│       └── screens/
│           ├── seller_dashboard.dart
│           ├── add_listing_screen.dart       ← загрузка фото + watermark
│           ├── my_listings_screen.dart       ← Firestore stream
│           └── seller_profile_screen.dart
```
