enum ListingStatus {
  draft,
  pending,
  approved,
  rejected,
  active,
  sold,
}

enum ListingCondition {
  brandNew,
  used,
  likeNew,
}

class Listing {
  final String id;
  final String sellerId;
  final String sellerName;
  final String name;
  final String description;
  final double price;
  final double? oldPrice;
  final String category;
  final String? brand;
  final ListingCondition condition;
  final List<String> images;
  final List<String>? compatibleCarBrands;
  final List<String>? compatibleCarModels;
  final List<int>? compatibleYears;
  final int stock;
  final ListingStatus status;
  final String? rejectionReason;
  final DateTime createdAt;
  final DateTime? approvedAt;
  final String? partNumber;
  final Map<String, String>? specifications;
  final bool isNegotiable;
  final String? location;

  Listing({
    required this.id,
    required this.sellerId,
    required this.sellerName,
    required this.name,
    required this.description,
    required this.price,
    this.oldPrice,
    required this.category,
    this.brand,
    required this.condition,
    required this.images,
    this.compatibleCarBrands,
    this.compatibleCarModels,
    this.compatibleYears,
    this.stock = 1,
    this.status = ListingStatus.draft,
    this.rejectionReason,
    required this.createdAt,
    this.approvedAt,
    this.partNumber,
    this.specifications,
    this.isNegotiable = false,
    this.location,
  });

  String get statusText {
    switch (status) {
      case ListingStatus.draft: return 'Черновик';
      case ListingStatus.pending: return 'На модерации';
      case ListingStatus.approved: return 'Одобрено';
      case ListingStatus.rejected: return 'Отклонено';
      case ListingStatus.active: return 'Активно';
      case ListingStatus.sold: return 'Продано';
    }
  }

  String get conditionText {
    switch (condition) {
      case ListingCondition.brandNew: return 'Новое';
      case ListingCondition.used: return 'Б/у';
      case ListingCondition.likeNew: return 'Как новое';
    }
  }
}
