enum SellerType {
  individual,
  shop,
  autoDismantle,
  dealer,
}

enum VerificationStatus {
  none,
  pending,
  verified,
  rejected,
}

class SellerProfile {
  final String id;
  final String name;
  final String phone;
  final String? email;
  final SellerType sellerType;
  final VerificationStatus verificationStatus;
  final String? businessName;
  final String? binIin;
  final String? city;
  final String? avatarUrl;
  final double rating;
  final int reviewCount;
  final DateTime createdAt;

  SellerProfile({
    required this.id,
    required this.name,
    required this.phone,
    this.email,
    this.sellerType = SellerType.individual,
    this.verificationStatus = VerificationStatus.none,
    this.businessName,
    this.binIin,
    this.city,
    this.avatarUrl,
    this.rating = 0.0,
    this.reviewCount = 0,
    required this.createdAt,
  });

  String get sellerTypeText {
    switch (sellerType) {
      case SellerType.individual: return 'Частное лицо';
      case SellerType.shop: return 'Магазин / ИП';
      case SellerType.autoDismantle: return 'Авторазбор';
      case SellerType.dealer: return 'Официальный дилер';
    }
  }

  String get sellerTypeIcon {
    switch (sellerType) {
      case SellerType.individual: return '👤';
      case SellerType.shop: return '🏪';
      case SellerType.autoDismantle: return '🔧';
      case SellerType.dealer: return '🏢';
    }
  }

  bool get requiresBusinessInfo =>
      sellerType == SellerType.shop ||
      sellerType == SellerType.dealer ||
      sellerType == SellerType.autoDismantle;

  String get verificationText {
    switch (verificationStatus) {
      case VerificationStatus.none: return 'Не верифицирован';
      case VerificationStatus.pending: return 'На рассмотрении';
      case VerificationStatus.verified: return 'Verified ✅';
      case VerificationStatus.rejected: return 'Отказано';
    }
  }

  bool get isVerified => verificationStatus == VerificationStatus.verified;
}
