import 'package:flutter/material.dart';
import '../models/listing.dart';

class StatusBadge extends StatelessWidget {
  final ListingStatus status;
  const StatusBadge({super.key, required this.status});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: _color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: _color.withOpacity(0.3)),
      ),
      child: Text(_text,
          style: TextStyle(
              color: _color, fontSize: 11, fontWeight: FontWeight.w600)),
    );
  }

  Color get _color {
    switch (status) {
      case ListingStatus.active: return Colors.green;
      case ListingStatus.pending: return Colors.orange;
      case ListingStatus.rejected: return Colors.red;
      case ListingStatus.sold: return const Color(0xFF2E6FF2);
      case ListingStatus.approved: return Colors.teal;
      case ListingStatus.draft: return Colors.grey;
    }
  }

  String get _text {
    switch (status) {
      case ListingStatus.active: return 'Активно';
      case ListingStatus.pending: return 'На проверке';
      case ListingStatus.rejected: return 'Отклонено';
      case ListingStatus.sold: return 'Продано';
      case ListingStatus.approved: return 'Одобрено';
      case ListingStatus.draft: return 'Черновик';
    }
  }
}
