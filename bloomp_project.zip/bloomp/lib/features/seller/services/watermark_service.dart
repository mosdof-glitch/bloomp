import 'dart:io';
import 'package:image/image.dart' as img;
import 'package:google_generative_ai/google_generative_ai.dart';
import '../../../config/gemini_config.dart';
import 'dart:convert';

class WatermarkService {
  static final WatermarkService _instance = WatermarkService._();
  static WatermarkService get instance => _instance;

  late GenerativeModel _visionModel;

  WatermarkService._() {
    _visionModel = GenerativeModel(
      model: GeminiConfig.visionModel,
      apiKey: GeminiConfig.apiKey,
    );
  }

  Future<Map<String, dynamic>> checkForWatermarks(File imageFile) async {
    try {
      final bytes = await imageFile.readAsBytes();
      const prompt = '''
Проверь это изображение на наличие водяных знаков (watermark) или логотипов сайтов.
Особенно ищи: kolesa.kz, OLX.kz, Krisha.kz, Market.kz, Satu.kz, Avito

ВАЖНО: Отвечай ТОЛЬКО в формате JSON!
{
  "has_watermark": true/false,
  "source_website": "название сайта или null",
  "confidence": 0.95,
  "watermark_location": "описание где находится",
  "is_allowed": true/false
}
''';
      final content = [
        Content.multi([TextPart(prompt), DataPart('image/jpeg', bytes)])
      ];
      final response = await _visionModel.generateContent(content);
      return _extractJson(response.text ?? '');
    } catch (e) {
      return {'has_watermark': false, 'is_allowed': true, 'error': e.toString()};
    }
  }

  Future<File> addBloomWatermark(File imageFile, String outputPath) async {
    try {
      final bytes = await imageFile.readAsBytes();
      img.Image? image = img.decodeImage(bytes);
      if (image == null) throw Exception('Не удалось декодировать изображение');

      final watermarkHeight = (image.height * 0.08).toInt();
      final x = image.width - (image.width * 0.3).toInt();
      final y = image.height - watermarkHeight - 20;

      img.fillRect(image,
          x1: x - 10, y1: y - 5,
          x2: image.width - 10, y2: y + watermarkHeight + 5,
          color: img.ColorRgba8(0, 0, 0, 100));

      img.drawString(image, 'BLOOMP',
          font: img.arial48, x: x, y: y,
          color: img.ColorRgba8(255, 255, 255, 200));

      final outputFile = File(outputPath);
      await outputFile.writeAsBytes(img.encodeJpg(image, quality: 90));
      return outputFile;
    } catch (e) {
      return imageFile;
    }
  }

  Future<Map<String, dynamic>> processImage(
      File imageFile, String outputDir) async {
    try {
      final checkResult = await checkForWatermarks(imageFile);
      if (checkResult['has_watermark'] == true &&
          checkResult['is_allowed'] == false) {
        return {
          'success': false,
          'error': 'На фото обнаружен watermark от ${checkResult['source_website']}',
          'blocked': true,
        };
      }
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final processedFile = await addBloomWatermark(
          imageFile, '$outputDir/bloomp_$timestamp.jpg');
      return {'success': true, 'file': processedFile, 'path': processedFile.path};
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }

  dynamic _extractJson(String text) {
    try {
      text = text.replaceAll('```json', '').replaceAll('```', '').trim();
      final match = RegExp(r'[\{\[][\s\S]*[\}\]]').firstMatch(text);
      if (match != null) return jsonDecode(match.group(0)!);
      return jsonDecode(text);
    } catch (e) {
      return {'error': 'Не удалось распарсить ответ AI', 'raw_response': text};
    }
  }
}
