import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../services/watermark_service.dart';
import '../models/listing.dart';
import 'package:path_provider/path_provider.dart';

class AddListingScreen extends StatefulWidget {
  const AddListingScreen({super.key});

  @override
  State<AddListingScreen> createState() => _AddListingScreenState();
}

class _AddListingScreenState extends State<AddListingScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _priceController = TextEditingController();
  final _oldPriceController = TextEditingController();
  final _stockController = TextEditingController(text: '1');
  final _partNumberController = TextEditingController();
  final _brandController = TextEditingController();

  final List<File> _images = [];
  final List<File> _processedImages = [];
  bool _isProcessingImages = false;

  String? _selectedCategory;
  ListingCondition _condition = ListingCondition.brandNew;
  bool _isNegotiable = false;
  String? _selectedCarBrand;

  final List<String> _categories = [
    'Масла', 'Фильтры', 'Тормоза', 'Шины',
    'Аккумуляторы', 'Свечи', 'Амортизаторы', 'Другое',
  ];

  final List<String> _carBrands = [
    'Toyota', 'BMW', 'Mercedes-Benz', 'Volkswagen',
    'Hyundai', 'Kia', 'Geely', 'Универсальное',
  ];

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _priceController.dispose();
    _oldPriceController.dispose();
    _stockController.dispose();
    _partNumberController.dispose();
    _brandController.dispose();
    super.dispose();
  }

  Future<void> _pickImages() async {
    if (_images.length >= 10) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Максимум 10 фотографий'),
          backgroundColor: Colors.red));
      return;
    }
    final picker = ImagePicker();
    final pickedFiles = await picker.pickMultiImage(
        maxWidth: 1920, maxHeight: 1920, imageQuality: 85);
    if (pickedFiles.isEmpty) return;

    final slotsAvailable = 10 - _images.length;
    final willBeSkipped = pickedFiles.length > slotsAvailable;
    setState(() => _isProcessingImages = true);

    for (var pickedFile in pickedFiles) {
      if (_images.length >= 10) break;
      final file = File(pickedFile.path);
      final result = await _processImage(file);
      if (result['success'] == true) {
        setState(() {
          _images.add(file);
          _processedImages.add(result['file']);
        });
      } else if (result['blocked'] == true) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text(result['error'] ?? 'Фото заблокировано'),
              backgroundColor: Colors.red,
              duration: const Duration(seconds: 3)));
        }
      }
    }

    setState(() => _isProcessingImages = false);

    if (willBeSkipped && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
              'Добавлено $slotsAvailable из ${pickedFiles.length} фото — достигнут лимит 10 штук'),
          backgroundColor: Colors.orange,
          duration: const Duration(seconds: 3)));
    }
  }

  Future<Map<String, dynamic>> _processImage(File imageFile) async {
    try {
      final appDir = await getApplicationDocumentsDirectory();
      final outputDir = '${appDir.path}/listings';
      await Directory(outputDir).create(recursive: true);
      return await WatermarkService.instance.processImage(imageFile, outputDir);
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }

  void _removeImage(int index) {
    setState(() {
      _images.removeAt(index);
      _processedImages.removeAt(index);
    });
  }

  Future<void> _submitListing() async {
    if (!_formKey.currentState!.validate()) return;
    if (_images.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Добавьте хотя бы одно фото'),
          backgroundColor: Colors.red));
      return;
    }
    if (_selectedCategory == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Выберите категорию'), backgroundColor: Colors.red));
      return;
    }
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('✅ Успешно!'),
        content: const Text(
            'Ваше объявление отправлено на модерацию.\n\nМы проверим его в течение 24 часов.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Добавить объявление',
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
            icon: const Icon(Icons.close, color: Colors.black),
            onPressed: () => Navigator.pop(context)),
        actions: [
          TextButton(
            onPressed: _submitListing,
            child: const Text('Опубликовать',
                style: TextStyle(color: Color(0xFFF91155),
                    fontWeight: FontWeight.bold, fontSize: 16)),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildPhotosSection(),
            const SizedBox(height: 24),
            _buildTextField(controller: _nameController,
                label: 'Название товара', hint: 'Масляный фильтр Toyota',
                validator: (v) => v == null || v.isEmpty ? 'Введите название' : null),
            const SizedBox(height: 16),
            _buildDropdown(label: 'Категория', value: _selectedCategory,
                items: _categories,
                onChanged: (v) => setState(() => _selectedCategory = v)),
            const SizedBox(height: 16),
            _buildTextField(controller: _brandController,
                label: 'Бренд (опционально)', hint: 'Mann, Bosch, NGK...'),
            const SizedBox(height: 16),
            _buildTextField(controller: _partNumberController,
                label: 'Артикул (опционально)', hint: 'C27009'),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(child: _buildTextField(
                    controller: _priceController, label: 'Цена', hint: '5000',
                    keyboardType: TextInputType.number, suffix: const Text('₸'),
                    validator: (v) => v == null || v.isEmpty ? 'Введите цену' : null)),
                const SizedBox(width: 16),
                Expanded(child: _buildTextField(
                    controller: _oldPriceController, label: 'Старая цена',
                    hint: '7000', keyboardType: TextInputType.number,
                    suffix: const Text('₸'))),
              ],
            ),
            const SizedBox(height: 16),
            _buildConditionSelector(),
            const SizedBox(height: 16),
            _buildTextField(controller: _stockController,
                label: 'Количество в наличии',
                keyboardType: TextInputType.number, suffix: const Text('шт.')),
            const SizedBox(height: 16),
            CheckboxListTile(
              value: _isNegotiable,
              onChanged: (v) => setState(() => _isNegotiable = v ?? false),
              title: const Text('Торг возможен'),
              activeColor: const Color(0xFFF91155),
              contentPadding: EdgeInsets.zero,
            ),
            const SizedBox(height: 24),
            const Text('Совместимость с автомобилями',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildDropdown(label: 'Марка', value: _selectedCarBrand,
                items: _carBrands,
                onChanged: (v) => setState(() => _selectedCarBrand = v)),
            const SizedBox(height: 24),
            _buildTextField(controller: _descriptionController,
                label: 'Описание', hint: 'Подробное описание товара...',
                maxLines: 5,
                validator: (v) => v == null || v.isEmpty ? 'Введите описание' : null),
            const SizedBox(height: 32),
            SizedBox(
              height: 56,
              child: ElevatedButton(
                onPressed: _submitListing,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFF91155),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                  elevation: 0,
                ),
                child: const Text('Опубликовать объявление',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: const Color(0xFFFFF0F5),
                  borderRadius: BorderRadius.circular(12)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(children: [
                    Icon(Icons.info_outline, color: Color(0xFFF91155)),
                    SizedBox(width: 8),
                    Text('Модерация',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  ]),
                  const SizedBox(height: 8),
                  Text(
                    'Ваше объявление будет проверено в течение 24 часов.\n\n'
                    '• Фото проверяются на наличие чужих watermark\n'
                    '• На одобренные фото добавляется watermark BLOOMP\n'
                    '• Запрещено использовать фото с других сайтов',
                    style: TextStyle(fontSize: 12, color: Colors.grey[700], height: 1.5),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPhotosSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Фотографии',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text('${_images.length}/10',
                style: TextStyle(color: Colors.grey[600], fontSize: 14)),
          ],
        ),
        const SizedBox(height: 12),
        if (_isProcessingImages)
          Container(
            height: 120,
            decoration: BoxDecoration(color: const Color(0xFFF5F5F7),
                borderRadius: BorderRadius.circular(12)),
            child: const Center(child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(color: Color(0xFFF91155)),
                SizedBox(height: 12),
                Text('Проверка и обработка фото...'),
              ],
            )),
          )
        else
          SizedBox(
            height: 120,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                GestureDetector(
                  onTap: _pickImages,
                  child: Container(
                    width: 120,
                    margin: const EdgeInsets.only(right: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF5F5F7),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFFE0E0E0), width: 2),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.add_photo_alternate,
                            size: 40, color: Color(0xFFF91155)),
                        const SizedBox(height: 8),
                        Text('Добавить',
                            style: TextStyle(color: Colors.grey[700], fontSize: 12)),
                      ],
                    ),
                  ),
                ),
                ..._processedImages.asMap().entries.map((entry) {
                  final index = entry.key;
                  final file = entry.value;
                  return Container(
                    width: 120,
                    margin: const EdgeInsets.only(right: 12),
                    child: Stack(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.file(file, width: 120, height: 120,
                              fit: BoxFit.cover),
                        ),
                        Positioned(
                          top: 4, right: 4,
                          child: GestureDetector(
                            onTap: () => _removeImage(index),
                            child: Container(
                              padding: const EdgeInsets.all(4),
                              decoration: const BoxDecoration(
                                  color: Colors.red, shape: BoxShape.circle),
                              child: const Icon(Icons.close,
                                  color: Colors.white, size: 16),
                            ),
                          ),
                        ),
                        if (index == 0)
                          Positioned(
                            bottom: 4, left: 4,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                  color: const Color(0xFFF91155),
                                  borderRadius: BorderRadius.circular(4)),
                              child: const Text('Главное',
                                  style: TextStyle(color: Colors.white,
                                      fontSize: 10, fontWeight: FontWeight.bold)),
                            ),
                          ),
                      ],
                    ),
                  );
                }),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    String? hint, int maxLines = 1,
    TextInputType? keyboardType, Widget? suffix,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller, maxLines: maxLines,
          keyboardType: keyboardType, validator: validator,
          decoration: InputDecoration(
            hintText: hint,
            suffixIcon: suffix != null
                ? Padding(padding: const EdgeInsets.only(right: 12), child: suffix)
                : null,
            suffixIconConstraints: const BoxConstraints(minWidth: 0, minHeight: 0),
            filled: true, fillColor: const Color(0xFFF5F5F7),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: Color(0xFFF91155), width: 2)),
            errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: Colors.red, width: 2)),
          ),
        ),
      ],
    );
  }

  Widget _buildDropdown({
    required String label, required String? value,
    required List<String> items, required ValueChanged<String?> onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(color: const Color(0xFFF5F5F7),
              borderRadius: BorderRadius.circular(12)),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value, isExpanded: true,
              hint: Text('Выберите $label'),
              items: items.map((item) =>
                  DropdownMenuItem(value: item, child: Text(item))).toList(),
              onChanged: onChanged,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildConditionSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Состояние',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(child: _buildConditionChip(
                label: 'Новое', value: ListingCondition.brandNew)),
            const SizedBox(width: 8),
            Expanded(child: _buildConditionChip(
                label: 'Б/у', value: ListingCondition.used)),
            const SizedBox(width: 8),
            Expanded(child: _buildConditionChip(
                label: 'Как новое', value: ListingCondition.likeNew)),
          ],
        ),
      ],
    );
  }

  Widget _buildConditionChip({
    required String label, required ListingCondition value,
  }) {
    final isSelected = _condition == value;
    return GestureDetector(
      onTap: () => setState(() => _condition = value),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFFF91155) : const Color(0xFFF5F5F7),
          borderRadius: BorderRadius.circular(12),
          border: isSelected ? null : Border.all(color: const Color(0xFFE0E0E0)),
        ),
        child: Text(label, textAlign: TextAlign.center,
            style: TextStyle(
                color: isSelected ? Colors.white : Colors.black87,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                fontSize: 14)),
      ),
    );
  }
}
