import 'package:flutter/material.dart';
import '../models/listing.dart';
import '../widgets/status_badge.dart';
import 'add_listing_screen.dart';
import 'my_listings_screen.dart';
import 'seller_profile_screen.dart';

class SellerDashboard extends StatefulWidget {
  const SellerDashboard({super.key});

  @override
  State<SellerDashboard> createState() => _SellerDashboardState();
}

class _SellerDashboardState extends State<SellerDashboard> {
  final String _sellerName = 'Автозапчасти PRO';
  final String _sellerType = 'Магазин / ИП';

  final Map<String, dynamic> _stats = {
    'active_listings': 18,
    'pending_listings': 3,
    'sold_items': 45,
    'total_revenue': 1250000,
    'this_month_revenue': 320000,
    'views': 1250,
    'favorites': 89,
    'rating': 4.8,
    'review_count': 127,
  };

  final List<Listing> _recentListings = [
    Listing(
      id: '1', sellerId: 'seller_123', sellerName: 'Автозапчасти PRO',
      name: 'Масляный фильтр Toyota Camry',
      description: 'Оригинальный масляный фильтр',
      price: 4150, oldPrice: 5500, category: 'Фильтры', brand: 'Toyota',
      condition: ListingCondition.brandNew,
      images: ['https://via.placeholder.com/300'],
      stock: 5, status: ListingStatus.active,
      createdAt: DateTime.now().subtract(const Duration(days: 2)),
    ),
    Listing(
      id: '2', sellerId: 'seller_123', sellerName: 'Автозапчасти PRO',
      name: 'Тормозные колодки Brembo',
      description: 'Передние тормозные колодки',
      price: 12000, category: 'Тормоза', brand: 'Brembo',
      condition: ListingCondition.brandNew,
      images: ['https://via.placeholder.com/300'],
      stock: 3, status: ListingStatus.pending,
      createdAt: DateTime.now().subtract(const Duration(hours: 5)),
    ),
    Listing(
      id: '3', sellerId: 'seller_123', sellerName: 'Автозапчасти PRO',
      name: 'Свечи зажигания NGK',
      description: 'Иридиевые свечи',
      price: 2400, category: 'Свечи', brand: 'NGK',
      condition: ListingCondition.brandNew,
      images: ['https://via.placeholder.com/300'],
      stock: 20, status: ListingStatus.active,
      createdAt: DateTime.now().subtract(const Duration(days: 5)),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F7),
      body: CustomScrollView(
        slivers: [
          _buildHeader(),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildQuickStats(),
                  const SizedBox(height: 16),
                  _buildRevenueCard(),
                  const SizedBox(height: 16),
                  _buildEngagementStats(),
                  const SizedBox(height: 24),
                  const Text('Быстрые действия',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  _buildQuickActions(),
                  const SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Последние объявления',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      TextButton(
                        onPressed: () => Navigator.push(context,
                            MaterialPageRoute(builder: (_) => const MyListingsScreen())),
                        child: const Text('Все'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  _buildRecentListings(),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const AddListingScreen())),
        backgroundColor: const Color(0xFFF91155),
        icon: const Icon(Icons.add),
        label: const Text('Добавить товар',
            style: TextStyle(fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _buildHeader() {
    return SliverAppBar(
      expandedHeight: 200,
      pinned: true,
      backgroundColor: const Color(0xFFF91155),
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFFF91155), Color(0xFFD30A4A)],
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 60, height: 60,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(30)),
                        child: const Icon(Icons.store,
                            color: Color(0xFFF91155), size: 30),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(_sellerName,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold)),
                            const SizedBox(height: 4),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(12)),
                              child: Text(_sellerType,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600)),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const SellerProfileScreen())),
                        icon: const Icon(Icons.settings, color: Colors.white),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Icon(Icons.star, color: Colors.amber, size: 20),
                      const SizedBox(width: 4),
                      Text(
                        '${_stats['rating']} (${_stats['review_count']} отзывов)',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildQuickStats() {
    return Row(
      children: [
        Expanded(child: _buildStatCard(
            icon: Icons.inventory_2, label: 'Активных',
            value: '${_stats['active_listings']}', color: Colors.green)),
        const SizedBox(width: 12),
        Expanded(child: _buildStatCard(
            icon: Icons.schedule, label: 'На проверке',
            value: '${_stats['pending_listings']}', color: Colors.orange)),
        const SizedBox(width: 12),
        Expanded(child: _buildStatCard(
            icon: Icons.shopping_bag, label: 'Продано',
            value: '${_stats['sold_items']}',
            color: const Color(0xFF2E6FF2))),
      ],
    );
  }

  Widget _buildStatCard({
    required IconData icon, required String label,
    required String value, required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10, offset: const Offset(0, 2))],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8)),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(height: 8),
          Text(value, style: const TextStyle(
              fontSize: 24, fontWeight: FontWeight.bold)),
          Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
        ],
      ),
    );
  }

  Widget _buildRevenueCard() {
    final totalRevenue = (_stats['total_revenue'] as num).toInt();
    final monthRevenue = (_stats['this_month_revenue'] as num).toInt();
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Color(0xFF2E6FF2), Color(0xFF1E5FD8)],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(
            color: const Color(0xFF2E6FF2).withOpacity(0.3),
            blurRadius: 15, offset: const Offset(0, 5))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('💰 Заработано',
                  style: TextStyle(color: Colors.white, fontSize: 16,
                      fontWeight: FontWeight.w600)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12)),
                child: const Text('За все время',
                    style: TextStyle(color: Colors.white, fontSize: 12,
                        fontWeight: FontWeight.w600)),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text('${_formatMoney(totalRevenue)} ₸',
              style: const TextStyle(color: Colors.white, fontSize: 32,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12)),
            child: Row(
              children: [
                const Icon(Icons.calendar_month, color: Colors.white, size: 20),
                const SizedBox(width: 8),
                Text('Этот месяц: ${_formatMoney(monthRevenue)} ₸',
                    style: const TextStyle(color: Colors.white, fontSize: 14,
                        fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEngagementStats() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10, offset: const Offset(0, 2))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Активность',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: _buildEngagementItem(
                  icon: Icons.visibility, label: 'Просмотры',
                  value: '${_stats['views']}', color: const Color(0xFF2E6FF2))),
              const SizedBox(width: 16),
              Expanded(child: _buildEngagementItem(
                  icon: Icons.favorite, label: 'В избранном',
                  value: '${_stats['favorites']}',
                  color: const Color(0xFFF91155))),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEngagementItem({
    required IconData icon, required String label,
    required String value, required Color color,
  }) {
    return Column(
      children: [
        Icon(icon, color: color, size: 32),
        const SizedBox(height: 8),
        Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
      ],
    );
  }

  Widget _buildQuickActions() {
    return Row(
      children: [
        Expanded(child: _buildActionButton(
          icon: Icons.add_circle, label: 'Добавить товар',
          color: const Color(0xFFF91155),
          onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const AddListingScreen())),
        )),
        const SizedBox(width: 12),
        Expanded(child: _buildActionButton(
          icon: Icons.inventory, label: 'Мои товары',
          color: const Color(0xFF2E6FF2),
          onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const MyListingsScreen())),
        )),
      ],
    );
  }

  Widget _buildActionButton({
    required IconData icon, required String label,
    required Color color, required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.3), width: 1.5),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(height: 8),
            Text(label, style: TextStyle(color: color, fontSize: 13,
                fontWeight: FontWeight.w600), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentListings() {
    return Column(
      children: _recentListings.map((listing) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10, offset: const Offset(0, 2))],
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  width: 80, height: 80,
                  color: const Color(0xFFF5F5F7),
                  child: const Icon(Icons.image, size: 40, color: Colors.grey),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(listing.name,
                        style: const TextStyle(fontSize: 15,
                            fontWeight: FontWeight.bold),
                        maxLines: 2, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 4),
                    Text('${listing.price.toStringAsFixed(0)} ₸',
                        style: const TextStyle(fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFFF91155))),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        StatusBadge(status: listing.status),
                        const SizedBox(width: 8),
                        Text('${listing.stock} шт.',
                            style: TextStyle(fontSize: 12,
                                color: Colors.grey[600])),
                      ],
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: () {},
                icon: const Icon(Icons.edit),
                color: const Color(0xFF2E6FF2),
              ),
            ],
          ),
        ),
      )).toList(),
    );
  }

  String _formatMoney(int amount) {
    return amount.toString().replaceAllMapped(
        RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]} ');
  }
}
