import 'package:flutter/material.dart';
import '../models/listing.dart';
import '../widgets/status_badge.dart';
import 'add_listing_screen.dart';

class MyListingsScreen extends StatefulWidget {
  const MyListingsScreen({super.key});

  @override
  State<MyListingsScreen> createState() => _MyListingsScreenState();
}

class _MyListingsScreenState extends State<MyListingsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  final List<Listing> _allListings = [
    Listing(
      id: '1', sellerId: 'seller_123', sellerName: 'Автозапчасти PRO',
      name: 'Масляный фильтр Toyota Camry V50',
      description: 'Оригинальный масляный фильтр',
      price: 4150, oldPrice: 5500, category: 'Фильтры', brand: 'Toyota',
      condition: ListingCondition.brandNew,
      images: ['https://via.placeholder.com/300'],
      stock: 5, status: ListingStatus.active,
      createdAt: DateTime.now().subtract(const Duration(days: 2)),
    ),
    Listing(
      id: '2', sellerId: 'seller_123', sellerName: 'Автозапчасти PRO',
      name: 'Тормозные колодки Brembo P83',
      description: 'Передние тормозные колодки',
      price: 12000, category: 'Тормоза', brand: 'Brembo',
      condition: ListingCondition.brandNew,
      images: ['https://via.placeholder.com/300'],
      stock: 3, status: ListingStatus.pending,
      createdAt: DateTime.now().subtract(const Duration(hours: 5)),
    ),
    Listing(
      id: '3', sellerId: 'seller_123', sellerName: 'Автозапчасти PRO',
      name: 'Свечи зажигания NGK Iridium',
      description: 'Иридиевые свечи',
      price: 2400, category: 'Свечи', brand: 'NGK',
      condition: ListingCondition.brandNew,
      images: ['https://via.placeholder.com/300'],
      stock: 20, status: ListingStatus.active,
      createdAt: DateTime.now().subtract(const Duration(days: 5)),
    ),
    Listing(
      id: '4', sellerId: 'seller_123', sellerName: 'Автозапчасти PRO',
      name: 'Воздушный фильтр Mann C27009',
      description: 'Многослойная фильтрация',
      price: 3500, category: 'Фильтры', brand: 'Mann',
      condition: ListingCondition.brandNew,
      images: ['https://via.placeholder.com/300'],
      stock: 0, status: ListingStatus.sold,
      createdAt: DateTime.now().subtract(const Duration(days: 10)),
    ),
    Listing(
      id: '5', sellerId: 'seller_123', sellerName: 'Автозапчасти PRO',
      name: 'Амортизатор Bilstein B4 задний',
      description: 'Газомасляный амортизатор',
      price: 24000, category: 'Амортизаторы', brand: 'Bilstein',
      condition: ListingCondition.used,
      images: ['https://via.placeholder.com/300'],
      stock: 2, status: ListingStatus.rejected,
      rejectionReason: 'Недостаточно фотографий товара',
      createdAt: DateTime.now().subtract(const Duration(days: 7)),
    ),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  List<Listing> _getListingsByStatus(ListingStatus? status) {
    if (status == null) return _allListings;
    return _allListings.where((l) => l.status == status).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F7),
      appBar: AppBar(
        title: const Text('Мои объявления',
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          labelColor: const Color(0xFFF91155),
          unselectedLabelColor: Colors.grey,
          indicatorColor: const Color(0xFFF91155),
          tabs: const [
            Tab(text: 'Все'),
            Tab(text: 'Активные'),
            Tab(text: 'На проверке'),
            Tab(text: 'Проданные'),
            Tab(text: 'Отклоненные'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildListingsList(null),
          _buildListingsList(ListingStatus.active),
          _buildListingsList(ListingStatus.pending),
          _buildListingsList(ListingStatus.sold),
          _buildListingsList(ListingStatus.rejected),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const AddListingScreen())),
        backgroundColor: const Color(0xFFF91155),
        icon: const Icon(Icons.add),
        label: const Text('Добавить'),
      ),
    );
  }

  Widget _buildListingsList(ListingStatus? status) {
    final listings = _getListingsByStatus(status);
    if (listings.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inventory_2_outlined, size: 80, color: Colors.grey[400]),
            const SizedBox(height: 16),
            Text('Нет объявлений',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600,
                    color: Colors.grey[700])),
            const SizedBox(height: 8),
            Text('Добавьте ваш первый товар',
                style: TextStyle(color: Colors.grey[500])),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: listings.length,
      itemBuilder: (context, index) => _buildListingCard(listings[index]),
    );
  }

  Widget _buildListingCard(Listing listing) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05),
            blurRadius: 10, offset: const Offset(0, 2))],
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Container(
                    width: 100, height: 100,
                    color: const Color(0xFFF5F5F7),
                    child: const Icon(Icons.image, size: 48, color: Colors.grey),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(listing.name,
                          style: const TextStyle(fontSize: 15,
                              fontWeight: FontWeight.bold),
                          maxLines: 2, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 8),
                      Text('${listing.price.toStringAsFixed(0)} ₸',
                          style: const TextStyle(fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFFF91155))),
                      const SizedBox(height: 4),
                      Text(listing.category,
                          style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          StatusBadge(status: listing.status),
                          const SizedBox(width: 8),
                          Text(
                            listing.status == ListingStatus.sold
                                ? 'Продано' : '${listing.stock} шт.',
                            style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (listing.status == ListingStatus.rejected &&
              listing.rejectionReason != null)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red[50],
                border: Border(top: BorderSide(color: Colors.red[200]!)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.error_outline, color: Colors.red, size: 20),
                  const SizedBox(width: 8),
                  Expanded(child: Text('Причина: ${listing.rejectionReason}',
                      style: const TextStyle(color: Colors.red, fontSize: 13))),
                ],
              ),
            ),
          if (listing.status != ListingStatus.sold)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                  border: Border(top: BorderSide(color: Colors.grey[200]!))),
              child: Row(
                children: [
                  if (listing.status == ListingStatus.active ||
                      listing.status == ListingStatus.rejected) ...[
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {},
                        icon: const Icon(Icons.edit, size: 18),
                        label: const Text('Редактировать'),
                        style: OutlinedButton.styleFrom(
                            foregroundColor: const Color(0xFF2E6FF2),
                            side: const BorderSide(color: Color(0xFF2E6FF2))),
                      ),
                    ),
                    const SizedBox(width: 8),
                  ],
                  if (listing.status == ListingStatus.pending)
                    const Expanded(
                      child: Text('Ожидает проверки модератором',
                          style: TextStyle(fontSize: 13, color: Colors.orange,
                              fontWeight: FontWeight.w600),
                          textAlign: TextAlign.center),
                    ),
                  if (listing.status == ListingStatus.rejected)
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () {},
                        icon: const Icon(Icons.refresh, size: 18),
                        label: const Text('Повторить'),
                        style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFF91155)),
                      ),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
