import 'package:flutter/material.dart';
import '../models/seller_profile.dart';

class SellerProfileScreen extends StatefulWidget {
  const SellerProfileScreen({super.key});

  @override
  State<SellerProfileScreen> createState() => _SellerProfileScreenState();
}

class _SellerProfileScreenState extends State<SellerProfileScreen> {
  final SellerProfile _profile = SellerProfile(
    id: 'seller_123',
    name: 'Автозапчасти PRO',
    phone: '+7 701 234 56 78',
    email: 'auto@example.kz',
    sellerType: SellerType.shop,
    verificationStatus: VerificationStatus.none,
    businessName: 'ИП Ахметов А.А.',
    city: 'Алматы',
    rating: 4.8,
    reviewCount: 127,
    createdAt: DateTime(2024, 1, 15),
  );

  SellerType _selectedType = SellerType.shop;
  bool _hasChanges = false;

  final _nameController = TextEditingController();
  final _businessNameController = TextEditingController();
  final _binController = TextEditingController();
  final _cityController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _selectedType = _profile.sellerType;
    _nameController.text = _profile.name;
    _businessNameController.text = _profile.businessName ?? '';
    _binController.text = _profile.binIin ?? '';
    _cityController.text = _profile.city ?? '';
  }

  @override
  void dispose() {
    _nameController.dispose();
    _businessNameController.dispose();
    _binController.dispose();
    _cityController.dispose();
    super.dispose();
  }

  void _saveProfile() {
    setState(() => _hasChanges = false);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Профиль сохранён'), backgroundColor: Colors.green));
  }

  void _requestVerification() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Запрос верификации'),
        content: const Text(
            'Мы проверим ваши данные в течение 1–3 рабочих дней.\n\n'
            'После верификации вы получите статус Verified ✅.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Отмена')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('Заявка отправлена — ждите ответа'),
                  backgroundColor: Colors.orange));
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF91155)),
            child: const Text('Подать заявку'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F7),
      appBar: AppBar(
        title: const Text('Настройки профиля',
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () => Navigator.pop(context)),
        actions: [
          if (_hasChanges)
            TextButton(
              onPressed: _saveProfile,
              child: const Text('Сохранить',
                  style: TextStyle(color: Color(0xFFF91155),
                      fontWeight: FontWeight.bold, fontSize: 16)),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildVerificationBanner(),
          const SizedBox(height: 20),
          _buildSectionTitle('Тип продавца'),
          const SizedBox(height: 12),
          _buildSellerTypeSelector(),
          const SizedBox(height: 20),
          _buildSectionTitle('Основная информация'),
          const SizedBox(height: 12),
          _buildInfoCard(),
          const SizedBox(height: 20),
          if (_selectedType != SellerType.individual) ...[
            _buildSectionTitle('Данные организации'),
            const SizedBox(height: 12),
            _buildBusinessCard(),
            const SizedBox(height: 20),
          ],
          SizedBox(
            height: 56,
            child: ElevatedButton(
              onPressed: _hasChanges ? _saveProfile : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF91155),
                disabledBackgroundColor: Colors.grey[300],
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                elevation: 0,
              ),
              child: const Text('Сохранить изменения',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold,
                      color: Colors.white)),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) => Text(title,
      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold,
          color: Colors.black87));

  Widget _buildVerificationBanner() {
    final status = _profile.verificationStatus;
    Color borderColor;
    Color bgColor;
    IconData icon;
    String title;
    String subtitle;
    bool showBtn;

    switch (status) {
      case VerificationStatus.verified:
        bgColor = Colors.green[50]!; borderColor = Colors.green;
        icon = Icons.verified; title = 'Verified ✅';
        subtitle = 'Ваш профиль верифицирован.'; showBtn = false;
        break;
      case VerificationStatus.pending:
        bgColor = Colors.orange[50]!; borderColor = Colors.orange;
        icon = Icons.hourglass_top; title = 'Заявка на рассмотрении';
        subtitle = 'Мы проверяем ваши данные. 1–3 рабочих дня.'; showBtn = false;
        break;
      case VerificationStatus.rejected:
        bgColor = Colors.red[50]!; borderColor = Colors.red;
        icon = Icons.cancel; title = 'Заявка отклонена';
        subtitle = 'Проверьте данные и подайте заявку повторно.'; showBtn = true;
        break;
      default:
        bgColor = const Color(0xFFF5F5F7);
        borderColor = const Color(0xFFE0E0E0);
        icon = Icons.shield_outlined; title = 'Получите статус Verified';
        subtitle = 'Верифицированные продавцы получают больше доверия и продаж.';
        showBtn = _selectedType != SellerType.individual;
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bgColor, borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor.withOpacity(0.4), width: 1.5),
      ),
      child: Row(
        children: [
          Icon(icon, color: borderColor, size: 32),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontWeight: FontWeight.bold,
                    fontSize: 15, color: borderColor)),
                const SizedBox(height: 4),
                Text(subtitle, style: TextStyle(fontSize: 12,
                    color: Colors.grey[700], height: 1.4)),
                if (showBtn) ...[
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 34,
                    child: ElevatedButton(
                      onPressed: _requestVerification,
                      style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFF91155),
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8)),
                          padding: const EdgeInsets.symmetric(horizontal: 16)),
                      child: const Text('Подать заявку',
                          style: TextStyle(fontSize: 13,
                              fontWeight: FontWeight.bold, color: Colors.white)),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSellerTypeSelector() {
    final types = [
      (SellerType.individual, '👤', 'Частное лицо', 'Продаю своё'),
      (SellerType.shop, '🏪', 'Магазин / ИП', 'Торговля'),
      (SellerType.autoDismantle, '🔧', 'Авторазбор', 'Разборка'),
      (SellerType.dealer, '🏢', 'Дилер', 'Официальный'),
    ];

    return Container(
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05),
              blurRadius: 10, offset: const Offset(0, 2))]),
      padding: const EdgeInsets.all(12),
      child: GridView.count(
        crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10,
        shrinkWrap: true, childAspectRatio: 2.8,
        physics: const NeverScrollableScrollPhysics(),
        children: types.map((entry) {
          final (type, icon, label, subtitle) = entry;
          final isSelected = _selectedType == type;
          return GestureDetector(
            onTap: () => setState(() {
              _selectedType = type;
              _hasChanges = true;
            }),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                color: isSelected
                    ? const Color(0xFFF91155).withOpacity(0.08)
                    : const Color(0xFFF5F5F7),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                    color: isSelected ? const Color(0xFFF91155) : const Color(0xFFE0E0E0),
                    width: isSelected ? 2 : 1),
              ),
              child: Row(
                children: [
                  Text(icon, style: const TextStyle(fontSize: 18)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(label, style: TextStyle(fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: isSelected ? const Color(0xFFF91155) : Colors.black87)),
                        Text(subtitle, style: TextStyle(fontSize: 10,
                            color: Colors.grey[500])),
                      ],
                    ),
                  ),
                  if (isSelected)
                    const Icon(Icons.check_circle,
                        color: Color(0xFFF91155), size: 16),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildInfoCard() {
    return Container(
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05),
              blurRadius: 10, offset: const Offset(0, 2))]),
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildField(controller: _nameController,
              label: 'Имя / Название', hint: 'Ваше имя или название магазина'),
          const SizedBox(height: 16),
          _buildReadOnlyField(label: 'Телефон',
              value: _profile.phone, icon: Icons.lock_outline),
          const SizedBox(height: 16),
          _buildField(controller: _cityController,
              label: 'Город', hint: 'Алматы, Астана...'),
        ],
      ),
    );
  }

  Widget _buildBusinessCard() {
    return Container(
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05),
              blurRadius: 10, offset: const Offset(0, 2))]),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Эти данные нужны для верификации',
              style: TextStyle(fontSize: 12, color: Colors.grey[600])),
          const SizedBox(height: 16),
          _buildField(controller: _businessNameController,
              label: 'Название организации', hint: 'ИП Иванов / ТОО AutoParts'),
          const SizedBox(height: 16),
          _buildField(controller: _binController,
              label: 'БИН / ИИН', hint: '123456789012',
              keyboardType: TextInputType.number),
        ],
      ),
    );
  }

  Widget _buildField({
    required TextEditingController controller,
    required String label, String? hint, TextInputType? keyboardType,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        TextField(
          controller: controller, keyboardType: keyboardType,
          onChanged: (_) => setState(() => _hasChanges = true),
          decoration: InputDecoration(
            hintText: hint, filled: true, fillColor: const Color(0xFFF5F5F7),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: Color(0xFFF91155), width: 2)),
          ),
        ),
      ],
    );
  }

  Widget _buildReadOnlyField({
    required String label, required String value, required IconData icon,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(color: const Color(0xFFF5F5F7),
              borderRadius: BorderRadius.circular(12)),
          child: Row(
            children: [
              Expanded(child: Text(value,
                  style: TextStyle(fontSize: 15, color: Colors.grey[600]))),
              Icon(icon, size: 18, color: Colors.grey[400]),
            ],
          ),
        ),
      ],
    );
  }
}
