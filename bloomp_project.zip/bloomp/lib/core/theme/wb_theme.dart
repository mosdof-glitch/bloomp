import 'package:flutter/material.dart';
import 'app_colors.dart';

class WBTheme {
  static const Color wbPrimary = AppColors.primary;
  static const Color wbBg = AppColors.background;
  static const Color wbWhite = AppColors.white;

  static ThemeData get theme => ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary),
        scaffoldBackgroundColor: AppColors.background,
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.white,
          foregroundColor: AppColors.textPrimary,
          elevation: 0,
        ),
      );
}
