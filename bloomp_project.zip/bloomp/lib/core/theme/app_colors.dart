import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFFF91155);
  static const Color primaryDark = Color(0xFFD30A4A);
  static const Color secondary = Color(0xFF2E6FF2);
  static const Color purple = Color(0xFF6C63FF);
  static const Color background = Color(0xFFF5F5F7);
  static const Color white = Color(0xFFFFFFFF);
  static const Color textPrimary = Color(0xFF1A1A1A);
  static const Color textSecondary = Color(0xFF6B7280);
  static const Color success = Color(0xFF10B981);
  static const Color warning = Color(0xFFF59E0B);
  static const Color error = Color(0xFFEF4444);
  static const Color grey100 = Color(0xFFF5F5F7);
  static const Color grey200 = Color(0xFFE5E7EB);
  static const Color grey300 = Color(0xFFD1D5DB);
  static const Color grey500 = Color(0xFF6B7280);
  static const Color grey700 = Color(0xFF374151);
  static const Color whatsapp = Color(0xFF25D366);
}
