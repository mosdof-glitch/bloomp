class MockProduct {
  final String id;
  final String name;
  final double price;
  final double? oldPrice;
  final String category;
  final String? brand;
  final String imageUrl;

  const MockProduct({
    required this.id,
    required this.name,
    required this.price,
    this.oldPrice,
    required this.category,
    this.brand,
    required this.imageUrl,
  });
}

class MockData {
  static List<MockProduct> getProducts() {
    return [
      const MockProduct(
        id: '1',
        name: 'Масляный фильтр Toyota Camry',
        price: 4150,
        oldPrice: 5500,
        category: 'Фильтры',
        brand: 'Toyota',
        imageUrl: 'https://via.placeholder.com/300x300',
      ),
      const MockProduct(
        id: '2',
        name: 'Тормозные колодки Brembo P83',
        price: 12000,
        category: 'Тормоза',
        brand: 'Brembo',
        imageUrl: 'https://via.placeholder.com/300x300',
      ),
      const MockProduct(
        id: '3',
        name: 'Свечи зажигания NGK Iridium',
        price: 2400,
        oldPrice: 3200,
        category: 'Свечи',
        brand: 'NGK',
        imageUrl: 'https://via.placeholder.com/300x300',
      ),
      const MockProduct(
        id: '4',
        name: 'Воздушный фильтр Mann C27009',
        price: 3500,
        category: 'Фильтры',
        brand: 'Mann',
        imageUrl: 'https://via.placeholder.com/300x300',
      ),
      const MockProduct(
        id: '5',
        name: 'Аккумулятор Varta Blue 60Ah',
        price: 45000,
        oldPrice: 52000,
        category: 'Аккумуляторы',
        brand: 'Varta',
        imageUrl: 'https://via.placeholder.com/300x300',
      ),
      const MockProduct(
        id: '6',
        name: 'Моторное масло Castrol 5W-30',
        price: 8500,
        oldPrice: 9900,
        category: 'Масла',
        brand: 'Castrol',
        imageUrl: 'https://via.placeholder.com/300x300',
      ),
    ];
  }
}
