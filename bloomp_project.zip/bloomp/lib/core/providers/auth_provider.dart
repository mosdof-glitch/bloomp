import 'package:flutter/material.dart';

class AuthProvider extends ChangeNotifier {
  bool _isAuthenticated = false;
  String? _userId;
  String? _userName;
  String? _userPhone;

  bool get isAuthenticated => _isAuthenticated;
  String? get userId => _userId;
  String? get userName => _userName;
  String? get userPhone => _userPhone;

  Future<bool> login(String phone, String password) async {
    await Future.delayed(const Duration(seconds: 1));
    _isAuthenticated = true;
    _userId = 'user_123';
    _userName = 'Пользователь';
    _userPhone = phone;
    notifyListeners();
    return true;
  }

  void logout() {
    _isAuthenticated = false;
    _userId = null;
    _userName = null;
    _userPhone = null;
    notifyListeners();
  }
}
